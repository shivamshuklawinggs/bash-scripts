const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const dbConfig = require('../config/db.config.js');

// Create Sequelize instance
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  dialect: dbConfig.dialect,
  pool: dbConfig.pool,
  logging: (msg) => console.log('[Database]', msg),
  define: {
    timestamps: true,
    freezeTableName: true
  }
});

const db = {
  sequelize,
  Sequelize
};

// Import all models from current directory
fs.readdirSync(__dirname)
  .filter(file => {
    return (file.indexOf('.') !== 0) && 
           (file !== 'index.js') && 
           (file.slice(-3) === '.js');
  })
  .forEach(file => {
    const model = require(path.join(__dirname, file))(sequelize, Sequelize);
    db[model.name] = model;
  });

// Initialize associations
Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

// Database sync and connection test
db.sync = async (force = false) => {
  try {
    await sequelize.authenticate();
    console.log('[Database] Connection established successfully.');

    // Drop tables if force is true
    if (force) {
      await sequelize.query('SET FOREIGN_KEY_CHECKS = 0');
      await sequelize.drop();
      await sequelize.sync();
      await sequelize.query('SET FOREIGN_KEY_CHECKS = 1');
    } else {
      await sequelize.sync();
    }
    
    console.log('[Database] Models synchronized successfully.');

    // Log registered models
    const models = Object.keys(db).filter(key => db[key].prototype instanceof Sequelize.Model);
    console.log('[Database] Registered models:', models);

    return true;
  } catch (error) {
    console.error('[Database] Initialization error:', error);
    throw error;
  }
};

// Export the db object
module.exports = db;
