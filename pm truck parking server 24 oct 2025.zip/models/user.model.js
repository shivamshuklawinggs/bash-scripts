const bcrypt = require('bcryptjs');

module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define('users', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: Sequelize.STRING(50),
      allowNull: false
    },
    email: {
      type: Sequelize.STRING(100),
      allowNull: false,
      unique: true
    },
    profilephoto: {
      type: Sequelize.STRING(500),
      allowNull: true
    },
    password: {
      type: Sequelize.STRING(255),
      allowNull: false
    },
    role: {
      type: Sequelize.STRING(10),
      defaultValue: 'user',
      allowNull: false
    },
    status: {
      type: Sequelize.STRING(10),
      defaultValue: 'active',
      allowNull: false
    }
  }, {
    tableName: 'users',
    timestamps: true,
    freezeTableName: true,
    hooks: {
      beforeCreate: async (user) => {
        if (user.password) {
          user.password = await bcrypt.hash(user.password, 10);
        }
      },
      beforeUpdate: async (user) => {
        if (user.changed('password')) {
          user.password = await bcrypt.hash(user.password, 10);
        }
      }
    }
  });

  User.prototype.validatePassword = async function(password) {
    if (!password || !this.password) return false;
    return bcrypt.compare(password, this.password);
  };

  User.associate = function(models) {
    User.hasMany(models.plates, {
      foreignKey: {
        name: 'userId',
        allowNull: true
      },
      as: 'plates',
      onDelete: 'SET NULL',
      constraints: false
    });
  };

  // Safe object conversion
  User.prototype.toJSON = function() {
    const values = Object.assign({}, this.get());
    delete values.password;
    return values;
  };

  return User;
};
