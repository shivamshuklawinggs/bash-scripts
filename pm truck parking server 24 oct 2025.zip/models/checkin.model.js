module.exports = (sequelize, Sequelize) => {
  const CheckIn = sequelize.define('checkins', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    plateId: {
      type: Sequelize.INTEGER,
      allowNull: false,
      references: {
        model: 'plates',
        key: 'id'
      }
    },
    checkInTime: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.NOW
    },
    checkOutTime: {
      type: Sequelize.DATE,
      allowNull: true
    },
    checkedInBy: {
      type: Sequelize.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    checkedOutBy: {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    status: {
      type: Sequelize.ENUM('checked-in', 'checked-out'),
      defaultValue: 'checked-in',
      allowNull: false
    },
    notes: {
      type: Sequelize.TEXT,
      allowNull: true
    },
    checkInPhotoUrl: {
      type: Sequelize.STRING(500),
      allowNull: true
    },
    location: {
      type: Sequelize.STRING(200),
      allowNull: true
    },
    point: {
      type: Sequelize.GEOMETRY('POINT'),
      allowNull: true
    },
    checkOutPhotoUrl: {
      type: Sequelize.STRING(500),
      allowNull: true
    }
  }, {
    tableName: 'checkins',
    timestamps: true,
    freezeTableName: true,
    indexes: [
      {
        fields: ['plateId']
      },
      {
        fields: ['checkedInBy']
      },
      {
        fields: ['status']
      }
    ]
  });

  CheckIn.associate = function(models) {
    CheckIn.belongsTo(models.plates, {
      foreignKey: 'plateId',
      as: 'plate'
    });
    CheckIn.belongsTo(models.users, {
      foreignKey: 'checkedInBy',
      as: 'checkedInByUser'
    });
    CheckIn.belongsTo(models.users, {
      foreignKey: 'checkedOutBy',
      as: 'checkedOutByUser'
    });
  };

  return CheckIn;
};
