module.exports = (sequelize, Sequelize) => {
  const Plate = sequelize.define('plates', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    number: {
      type: Sequelize.STRING(20),
      allowNull: false,
      unique: {
        args: true,
        msg: 'This plate number is already registered'
      },
      validate: {
        notEmpty: {
          msg: 'Plate number cannot be empty'
        },
        len: {
          args: [2, 20],
          msg: 'Plate number must be between 2 and 20 characters'
        }
      }
    },
    vehicleType: {
      type: Sequelize.ENUM('car', 'truck'),
      defaultValue: 'car',
      allowNull: false,
      validate: {
        isIn: {
          args: [['car', 'truck']],
          msg: 'Vehicle type must be car or truck'
        }
      }
    },
    status: {
      type: Sequelize.ENUM('active', 'inactive'),
      defaultValue: 'active',
      allowNull: false,
      validate: {
        isIn: {
          args: [['active', 'inactive']],
          msg: 'Status must be either active or inactive'
        }
      }
    },
    userId: {
      type: Sequelize.INTEGER,
      allowNull: true,
      defaultValue: null
    },
    photoUrl: {
      type: Sequelize.STRING(500),
      allowNull: true
    },
    latitude: {
      type: Sequelize.DECIMAL(10, 8),
      allowNull: true,
      validate: {
        isDecimal: {
          msg: 'Invalid latitude format'
        },
        min: {
          args: [-90],
          msg: 'Latitude must be greater than or equal to -90'
        },
        max: {
          args: [90],
          msg: 'Latitude must be less than or equal to 90'
        }
      }
    },
    longitude: {
      type: Sequelize.DECIMAL(11, 8),
      allowNull: true,
      validate: {
        isDecimal: {
          msg: 'Invalid longitude format'
        },
        min: {
          args: [-180],
          msg: 'Longitude must be greater than or equal to -180'
        },
        max: {
          args: [180],
          msg: 'Longitude must be less than or equal to 180'
        }
      }
    },
    locationName: {
      type: Sequelize.STRING(200),
      allowNull: true
    },
    point: {
      type: Sequelize.GEOMETRY('POINT'),
      allowNull: true
    },
    CompanyName: {
      type: Sequelize.STRING(),
      allowNull: true,
    },
    Name:{
      type: Sequelize.STRING(),
      allowNull: false,
    },
    Phone:{
      type: Sequelize.STRING(),
      allowNull: false,
    },
    
    Email:{
      type: Sequelize.STRING(),
      allowNull: true,
    },
    MakeModel:{
      type: Sequelize.STRING(),
      allowNull: true,
    },
    Color:{
      type: Sequelize.STRING(),
      allowNull: true,
    },
    Rent:{
      type: Sequelize.INTEGER(),
      allowNull: true,
    },
    // Remote  checkin
    Remote:{
      type: Sequelize.BOOLEAN,
      allowNull: false,
      defaultValue: false
    },
    RemoteNumber:{
      type: Sequelize.STRING(),
      allowNull: true,
    },
    DriverName:{
      type: Sequelize.STRING(),
      allowNull: true,
    },
    DriverPhone:{
      type: Sequelize.STRING(),
      allowNull: true,
    },
    isUnregistered: {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
    },
    temporaryDetails: {
      type: Sequelize.JSON,
      defaultValue: null,
    },
    lastCheckedInBy: {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    lastCheckedInAt: {
      type: Sequelize.DATE,
      allowNull: true
    }
  }, {
    tableName: 'plates',
    timestamps: true,
    freezeTableName: true,
    indexes: [
      {
        unique: true,
        fields: ['number']
      },
      {
        fields: ['userId']
      },
      {
        fields: ['status']
      },
      {
        fields: ['vehicleType']
      }
    ]
  });
// before update or create hook
Plate.beforeUpdate((plate) => {
  plate.number = plate.number.toUpperCase();
  if(plate.RemoteNumber) plate.RemoteNumber = plate.RemoteNumber.toUpperCase();
});
Plate.beforeCreate((plate) => {
  plate.number = plate.number.toUpperCase();
  if(plate.RemoteNumber) plate.RemoteNumber = plate.RemoteNumber.toUpperCase();
});
  Plate.associate = function(models) {
    Plate.belongsTo(models.users, {
      foreignKey: 'userId',
      as: 'user',
      onDelete: 'SET NULL'
    });

    // Add hasMany relationship with checkins
    Plate.hasMany(models.checkins, {
      foreignKey: 'plateId',
      as: 'checkins',
      onDelete: 'CASCADE'
    });
  };

  // Safe object conversion
  Plate.prototype.toJSON = function() {
    const values = Object.assign({}, this.get());
    return values;
  };

  return Plate;
};
