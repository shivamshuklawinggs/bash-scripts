require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('../models');
const User = db.user;

const adminCredentials = {
  username: 'admin',
  email: 'admin@parking.com',
  password: 'admin123',
  role: 'admin'
};

async function seedAdmin() {
  try {
    const hashedPassword = await bcrypt.hash(adminCredentials.password, 10);
    
    await User.findOrCreate({
      where: { email: adminCredentials.email },
      defaults: {
        ...adminCredentials,
        password: hashedPassword
      }
    });

    console.log('Admin user created successfully');
    console.log('Email:', adminCredentials.email);
    console.log('Password:', adminCredentials.password);
    
    process.exit(0);
  } catch (error) {
    console.error('Error creating admin:', error);
    process.exit(1);
  }
}

seedAdmin();
