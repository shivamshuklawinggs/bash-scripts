DROP DATABASE IF EXISTS parking_system;
CREATE DATABASE parking_system;
USE parking_system;

-- Drop existing tables if they exist (in correct order)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS plates;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- Create users table first
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('user', 'admin') DEFAULT 'user',
  status ENUM('active', 'inactive') DEFAULT 'active',
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create plates table with foreign key
CREATE TABLE plates (
  id INT PRIMARY KEY AUTO_INCREMENT,
  number VARCHAR(20) NOT NULL UNIQUE,
  vehicleType ENUM('car', 'truck') DEFAULT 'car',
  status ENUM('active', 'inactive') DEFAULT 'active',
  userId INT NOT NULL,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert initial admin user (password: admin123)
INSERT INTO users (username, email, password, role, status) VALUES 
('admin', 'admin@example.com', '$2a$10$mj1yZwgLz8GFx5r/CZr3.OtNTF0JSqZ.srh0mI5YyXs4bhqytO/Se', 'admin', 'active');

-- Insert test user (password: test123)
INSERT INTO users (username, email, password, role, status) VALUES 
('testuser', 'test@example.com', '$2a$10$mj1yZwgLz8GFx5r/CZr3.OtNTF0JSqZ.srh0mI5YyXs4bhqytO/Se', 'user', 'active');

-- Insert test plates for test user
INSERT INTO plates (number, vehicleType, userId) VALUES 
('ABC123', 'car', 2),
('XYZ789', 'car', 2);
