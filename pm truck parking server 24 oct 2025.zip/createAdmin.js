require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const dbConfig = require('./config/db.config');

const adminUser = {
  username: 'admin',
  email: 'admin@parking.com',
  password: 'admin123',
  role: 'admin'
};

async function createAdmin() {
  try {
    const connection = await mysql.createConnection({
      host: dbConfig.HOST,
      user: dbConfig.USER,
      password: dbConfig.PASSWORD,
      database: dbConfig.DB
    });

    const hashedPassword = await bcrypt.hash(adminUser.password, 10);
    const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
    
    await connection.execute(
      'INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)',
      [adminUser.username, adminUser.email, hashedPassword, adminUser.role, now, now]
    );

    console.log('Admin user created successfully:');
    console.log('Email:', adminUser.email);
    console.log('Password:', adminUser.password);
    
    await connection.end();
    process.exit(0);
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      console.log('Admin user already exists');
      process.exit(0);
    }
    console.error('Error creating admin:', error);
    process.exit(1);
  }
}

createAdmin();
