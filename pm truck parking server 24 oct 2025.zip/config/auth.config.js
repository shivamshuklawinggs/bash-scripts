module.exports = {
  secret: process.env.JWT_SECRET || "your-super-secret-jwt-key",
  // Token will expire in 24 hours
  jwtExpiration: process.env.JWT_EXPIRES_IN || '24h',
}; 