require('dotenv').config();
const NODE_ENV = process.env.NODE_ENV || 'production';
module.exports = {
    DB_PASSWORD:NODE_ENV==="development"? process.env.DB_PASSWORD: process.env.PRODUCTION_DB_PASSWORD,
    DB_USER: NODE_ENV==="development"? process.env.DB_USER: process.env.PRODUCTION_DB_USER,
    };