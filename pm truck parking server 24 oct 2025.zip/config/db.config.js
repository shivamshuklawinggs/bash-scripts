const { DB_PASSWORD, DB_USER } = require('.');

require('dotenv').config();

module.exports = {
  HOST: process.env.DB_HOST || "127.0.0.1",
  USER: DB_USER,
  PASSWORD: DB_PASSWORD,
  DB: process.env.DB_NAME || "pmtdb",
  dialect: "mysql",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  logging: console.log, // Enable logging temporarily for debugging
  define: {
    timestamps: true,
    freezeTableName: true
  }
};
