'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // await queryInterface.createTable('checkins', {
    //   id: {
    //     type: Sequelize.INTEGER,
    //     primaryKey: true,
    //     autoIncrement: true
    //   },
    //   plateId: {
    //     type: Sequelize.INTEGER,
    //     allowNull: false,
    //     references: {
    //       model: 'plates',
    //       key: 'id'
    //     },
    //     onUpdate: 'CASCADE',
    //     onDelete: 'CASCADE'
    //   },
    //   checkInTime: {
    //     type: Sequelize.DATE,
    //     allowNull: false,
    //     defaultValue: Sequelize.NOW
    //   },
    //   checkOutTime: {
    //     type: Sequelize.DATE,
    //     allowNull: true
    //   },
    //   checkedInBy: {
    //     type: Sequelize.INTEGER,
    //     allowNull: false,
    //     references: {
    //       model: 'users',
    //       key: 'id'
    //     },
    //     onUpdate: 'CASCADE',
    //     onDelete: 'SET NULL'
    //   },
    //   checkedOutBy: {
    //     type: Sequelize.INTEGER,
    //     allowNull: true,
    //     references: {
    //       model: 'users',
    //       key: 'id'
    //     },
    //     onUpdate: 'CASCADE',
    //     onDelete: 'SET NULL'
    //   },
    //   status: {
    //     type: Sequelize.ENUM('checked-in', 'checked-out'),
    //     defaultValue: 'checked-in',
    //     allowNull: false
    //   },
    //   notes: {
    //     type: Sequelize.TEXT,
    //     allowNull: true
    //   },
    //   createdAt: {
    //     type: Sequelize.DATE,
    //     allowNull: false
    //   },
    //   updatedAt: {
    //     type: Sequelize.DATE,
    //     allowNull: false
    //   }
    // });

    // await queryInterface.addIndex('checkins', ['plateId']);
    // await queryInterface.addIndex('checkins', ['checkedInBy']);
    // await queryInterface.addIndex('checkins', ['status']);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('checkins');
  }
};
