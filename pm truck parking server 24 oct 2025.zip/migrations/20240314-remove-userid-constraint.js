'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Remove the NOT NULL constraint from userId
    await queryInterface.changeColumn('plates', 'userId', {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id'
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    // Revert back to NOT NULL constraint
    await queryInterface.changeColumn('plates', 'userId', {
      type: Sequelize.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    });
  }
};
