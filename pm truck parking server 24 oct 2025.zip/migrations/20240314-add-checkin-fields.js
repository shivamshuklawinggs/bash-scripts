'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // await queryInterface.addColumn('plates', 'lastCheckedInBy', {
    //   type: Sequelize.INTEGER,
    //   allowNull: true,
    //   references: {
    //     model: 'users',
    //     key: 'id'
    //   }
    // });

    // await queryInterface.addColumn('plates', 'lastCheckedInAt', {
    //   type: Sequelize.DATE,
    //   allowNull: true
    // });
    // await queryInterface.addColumn('plates', 'CompanyName', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });

    // await queryInterface.addColumn('plates', 'Name', {
    //   type: Sequelize.STRING(),
    //   allowNull: false
    // });

    // await queryInterface.addColumn('plates', 'Phone', {
    //   type: Sequelize.STRING(),
    //   allowNull: false
    // });

    // await queryInterface.addColumn('plates', 'Email', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });

    // await queryInterface.addColumn('plates', 'MakeModel', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });

    // await queryInterface.addColumn('plates', 'Color', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });
    // await queryInterface.addColumn('plates', 'DriverName', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });
    // await queryInterface.addColumn('plates', 'RemoteNumber', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });
    // await queryInterface.addColumn('plates', 'DriverPhone', {
    //   type: Sequelize.STRING(),
    //   allowNull: true
    // });
    // await queryInterface.addColumn('plates', 'isUnregistered', {
    //   type: Sequelize.BOOLEAN,
    //   allowNull: false,
    //   defaultValue: false
    // });
    // await queryInterface.addColumn('plates', 'temporaryDetails', {
    //   type: Sequelize.JSON,
    //   allowNull: true
    // });

    // await queryInterface.addColumn('plates', 'Rent', {
    //   type: Sequelize.INTEGER(),
    //   allowNull: true
    // });

  //   await queryInterface.addColumn('plates', 'Remote', {
  //     type: Sequelize.BOOLEAN,
  //     allowNull: false,
  //     defaultValue: false
  //   });
  // // checking point ,locations column
    await queryInterface.addColumn('checkins', 'point', {
      type: Sequelize.GEOMETRY('POINT'),
      allowNull: true
    });
  //  location column
    await queryInterface.addColumn('checkins', 'location', {
      type: Sequelize.STRING(200),
      allowNull: true
    });
    // Add index for lastCheckedInBy
    // await queryInterface.addIndex('plates', ['lastCheckedInBy']);
  },

  down: async (queryInterface, Sequelize) => {
    // await queryInterface.removeIndex('plates', ['lastCheckedInBy']);
    // await queryInterface.removeColumn('plates', 'lastCheckedInBy');
    // await queryInterface.removeColumn('plates', 'lastCheckedInAt');
    // await queryInterface.removeColumn('plates', 'CompanyName');
    // await queryInterface.removeColumn('plates', 'Name');
    // await queryInterface.removeColumn('plates', 'Phone');
    // await queryInterface.removeColumn('plates', 'Email');
    // await queryInterface.removeColumn('plates', 'MakeModel');
    // await queryInterface.removeColumn('plates', 'Color');
    // await queryInterface.removeColumn('plates', 'Rent');
    // await queryInterface.removeColumn('plates', 'Remote');
  }
};



