require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('../models');

async function initializeDatabase() {
  try {
    // Force sync all models
    console.log('Syncing database...');
    await db.sequelize.sync({ force: true });
    console.log('Database synchronized successfully');

    // Create admin user
    console.log('Creating admin user...');
    const adminUser = await db.user.create({
      username: 'admin',
      email: 'admin@example.com',
      password: 'admin123', // Will be hashed by model hooks
      role: 'admin'
    });

    console.log('Admin user created successfully:', {
      id: adminUser.id,
      username: adminUser.username,
      email: adminUser.email,
      role: adminUser.role
    });

    // Create test user
    console.log('Creating test user...');
    const testUser = await db.user.create({
      username: 'testuser',
      email: 'test@example.com',
      password: 'test123', // Will be hashed by model hooks
      role: 'user'
    });

    console.log('Test user created successfully:', {
      id: testUser.id,
      username: testUser.username,
      email: testUser.email,
      role: testUser.role
    });

    // Create some test plates for the test user
    console.log('Creating test plates...');
    await db.plate.create({
      number: 'ABC123',
      ownerId: testUser.id
    });

    await db.plate.create({
      number: 'XYZ789',
      ownerId: testUser.id
    });

    console.log('Test plates created successfully');

  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error; // Re-throw to see full error details
  } finally {
    // Close the database connection
    await db.sequelize.close();
    console.log('Database connection closed');
  }
}

// Run the initialization
console.log('Starting database initialization...');
initializeDatabase();
