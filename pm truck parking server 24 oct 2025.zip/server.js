require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./models');
const { up, down } = require('./migrations/20240314-add-checkin-fields');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');

// Initialize Express app
const app = express();

// Middleware setup
app.use(cors({
  origin: ["http://localhost:3001","https://crm.pmtruckparking.com", "http://localhost:5002"],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'x-access-token']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging middleware
// app.use((req, res, next) => {
//   console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
//   if (req.body && Object.keys(req.body).length) {
//     console.log('Request body:', JSON.stringify(req.body, null, 2));
//   }
//   next();
// });

// Response logging middleware
// app.use((req, res, next) => {
//   const originalJson = res.json;
//   res.json = function(data) {
//     const responseData = JSON.stringify(data, null, 2);
//     console.log(`[Response] ${req.method} ${req.url}:`, responseData);
//     return originalJson.call(this, data);
//   };
//   next();
// });

// Routes
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/users', require('./routes/user.routes'));
app.use('/api/plates', require('./routes/plate.routes'));
app.use('/api/dashboard', require('./routes/dashboard.routes'));

// Swagger UI route with CORS enabled
app.use('/api-docs', (req, res, next) => {
  // Enable CORS for Swagger UI
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  next();
}, swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  swaggerOptions: {
    persistAuthorization: true
  }
}));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    database: 'connected',
    server: 'running'
  });
});

app.use("/uploads",express.static('uploads'));

// Global error handler
app.use((err, req, res, next) => {
  console.error('[Error]', err);
  const status = err.status || 500;
  const message = err.message || 'Internal server error';
  res.status(status).json({
    error: {
      message,
      status,
      timestamp: new Date().toISOString()
    }
  });
});

// Initialize database and start server
const PORT = process.env.PORT || 5003;

const initializeServer = async () => {
  try {
    // Initialize database
    await db.sync();
    // await db.sequelize.getQueryInterface().addColumn('users', 'profilephoto', {
    //   type: Sequelize.STRING(500),
    //   allowNull: true
    // });
    // await down(db.sequelize.getQueryInterface(),db.Sequelize );
    // await up(db.sequelize.getQueryInterface(),db.Sequelize );

    // Create admin user if not exists
    const bcrypt = require('bcryptjs');
    const adminUser = await db.users.findOne({
      where: { email: 'admin@example.com' }
    });
    
    if (!adminUser) {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      await db.users.create({
        username: 'admin',
        email: 'admin@example.com',
        password: hashedPassword,
        role: 'admin',
        status: 'active'
      });
      console.log('Admin user created successfully');
    }

    // Start server
    app.listen(PORT, () => {
      console.log('='.repeat(50));
      console.log('Server Configuration:');
      console.log('-'.repeat(50));
      console.log(`Port: ${PORT}`);
      console.log(`Database: ${process.env.DB_NAME}`);
      console.log(`Host: ${process.env.DB_HOST}`);
      console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log('='.repeat(50));
    });

  } catch (error) {
    console.error('Server initialization failed:', error);
    process.exit(1);
  }
};

initializeServer();
// get hostip
const getHostIp = () => {
  const os = require('os');
  const interfaces = os.networkInterfaces();
  for (const interfaceName in interfaces) {
    const interfaceInfo = interfaces[interfaceName];
    console.log(interfaceInfo)
    for (const interfaceAddress of interfaceInfo) {
      if (interfaceAddress.family === 'IPv4' && !interfaceAddress.internal) {
        return interfaceAddress.address;
      }
    }
  }
};
console.log('Host IP:', getHostIp());
