const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../models');
const config = require('../config/auth.config');
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log('[Auth] Login attempt for:', email);

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    // Find user with plates association
    const user = await db.users.findOne({
      where: { 
        email,
        status: 'active'
      },
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status']
      }]
    });

    console.log('[Auth] User found:', user ? 'yes' : 'no');
    if (!user) {
      return res.status(404).json({ message: 'User not found or inactive' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    console.log('[Auth] Password valid:', isValidPassword ? 'yes' : 'no');
    
    if (!isValidPassword) {
      return res.status(401).json({ message: 'Invalid password' });
    }

    const token = jwt.sign(
      { 
        id: user.id, 
        role: user.role,
        email: user.email,
        username: user.username
      },
      config.secret,
      { expiresIn: '24h' }
    );

    console.log('[Auth] Login successful for user:', user.username);
    
    // Use the model's toJSON method to safely serialize user data
    const userData = user.toJSON();
    res.json({
      user: {
        ...userData,
        plates: userData.plates || []
      },
      token
    });
  } catch (error) {
    console.error('[Auth] Login error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    res.status(500).json({ 
      message: 'Server error during login',
      error: error.message 
    });
  }
};

exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    console.log('[Auth] Registration attempt for:', email);

    if (!username || !email || !password) {
      return res.status(400).json({ 
        message: 'Username, email, and password are required' 
      });
    }

    // Check if user already exists
    const existingUser = await db.users.findOne({
      where: {
        [db.Sequelize.Op.or]: [
          { email },
          { username }
        ]
      }
    });

    if (existingUser) {
      return res.status(400).json({ 
        message: 'Email or username already exists' 
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await db.users.create({
      username,
      email,
      password: hashedPassword,
      role: 'user',
      status: 'active'
    });

    const token = jwt.sign(
      { 
        id: user.id, 
        role: user.role,
        email: user.email 
      },
      process.env.JWT_SECRET || 'your-super-secret-jwt-key',
      { expiresIn: '24h' }
    );

    console.log('[Auth] Registration successful for:', username);
    res.status(201).json({
      message: 'User registered successfully',
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        status: user.status
      },
      token
    });
  } catch (error) {
    console.error('[Auth] Registration error:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    res.status(500).json({ 
      message: 'Server error during registration',
      error: error.message 
    });
  }
};

exports.getProfile = async (req, res) => {
  try {
    const user = await db.users.findByPk(req.user.id, {
      attributes: ['id', 'username', 'email', 'role', 'status']
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user);
  } catch (error) {
    console.error('[Auth] Get profile error:', error);
    res.status(500).json({ 
      message: 'Server error while fetching profile',
      error: error.message 
    });
  }
};
