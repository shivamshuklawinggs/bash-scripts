const yup = require('yup');
const db = require('../models');
const Plate = db.plates;
const User = db.users;
const CheckIn = db.checkins;
const { uploadToCloudinary } = require('../utils/cloudinary');
const { Sequelize } = require('sequelize');
const fs = require('fs').promises;
const { Op } = db.Sequelize;

const plateSchema = yup.object().shape({
  number: yup.string().required().min(2).max(20),
  vehicleType: yup.string().oneOf(['car', 'truck']).required(),
  status: yup.string().oneOf(['active', 'inactive']).default('active')
});

exports.createPlate = async (req, res) => {
  try {
    console.log('[Create Plate] Request received');
    console.log('[Create Plate] Body:', req.body);
    
    // Initialize plate data
    let plateData = {
      number: req.body.number || req.body.plateNumber, // Handle both field names
      vehicleType: req.body.vehicleType,
      CompanyName: req.body.CompanyName,
      Name: req.body.Name || '',
      Phone: req.body.Phone || '',
      Email: req.body.Email || '',
      MakeModel: req.body.MakeModel || '',
      Color: req.body.Color || '',
      Rent: req.body.Rent || '',
      Remote: req.body.Remote || false,
      status: 'active', // Always active for new plates
      userId: req.user?.id || null // Use the authenticated user's ID if available
      
    };

    // Validate request data
    const validatedData = await plateSchema.validate(plateData);
    console.log('[Create Plate] Validated data:', validatedData);
    
    // Check if plate number already exists
    const existingPlate = await Plate.findOne({
      where: { number: validatedData.number }
    });

    if (existingPlate) {
      return res.status(400).json({
        message: 'This license plate number is already registered'
      });
    }
    
    // Create plate
    console.log('[Create Plate] Creating plate...');
    const plate = await Plate.create(validatedData);
    
    // Fetch plate with user details
    const createdPlate = await Plate.findByPk(plate.id, {
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }]
    });
    
    console.log('[Create Plate] Plate created successfully:', createdPlate.id);
    
    res.status(201).json({
      message: 'License plate created successfully',
      plate: createdPlate
    });
  } catch (error) {
    console.error('[Create Plate] Error:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: error.message });
    }
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'License plate number already exists' });
    }
    res.status(500).json({ 
      message: 'Failed to create license plate. Please try again.',
      error: error.message
    });
  }
};

exports.getUserPlates = async (req, res) => {
  try {
    console.log('[Get User Plates] Request received');
    
    const plates = await Plate.findAll({
      where: { userId: req.user.id },
      include: [
        {
          model: db.users,
          as: 'user',
          attributes: ['id', 'username', 'email']
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    console.log('[Get User Plates] Found plates:', plates.length);
    
    return res.status(200).json({
      plates,
      count: plates.length
    });
  } catch (error) {
    console.error('[Get User Plates] Error:', error);
    return res.status(500).json({
      message: 'Failed to fetch user plates',
      error: error.message
    });
  }
};

exports.getAllPlates = async (req, res) => {
  try {
    const {isUnregistered=true} = req.query;
    console.log('[Get All Plates] Request received');
    console.log('[Get All Plates] User:', req.user);
    
    const plates = await Plate.findAll({
      where: { isUnregistered: isUnregistered =='true' },
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }],
      order: [['createdAt', 'DESC']]
    });
    
    console.log(`[Get All Plates] Found ${plates.length} plates`);
    
    // Convert Sequelize instances to plain objects
    const plainPlates = plates.map(plate => {
      const plainPlate = plate.get({ plain: true });
      return {
        ...plainPlate,
        user: plainPlate.user || null
      };
    });
    
    res.json({
      count: plainPlates.length,
      plates: plainPlates
    });
  } catch (error) {
    console.error('[Get All Plates] Error:', error);
    res.status(500).json({ 
      message: 'Server error',
      error: {
        name: error.name,
        message: error.message
      }
    });
  }
};

exports.getPlatesByUser = async (req, res) => {
  try {
    const { userId } = req.params;
    console.log(`[Get Plates By User] Request received for user ${userId}`);
    
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const plates = await Plate.findAll({
      where: { userId },
      include: [{
        model: User,
        as: 'owner',
        attributes: ['id', 'username', 'email']
      }]
    });
    
    console.log(`[Get Plates By User] Found ${plates.length} plates for user ${userId}`);
    res.json(plates);
  } catch (error) {
    console.error('[Get Plates By User] Error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.updatePlate = async (req, res) => {
  const { id } = req.params;
  try {
    console.log(`[Update Plate] Request received for plate ${id}:`, req.body);
    
    const plate = await Plate.findByPk(id);
    if (!plate) {
      return res.status(404).json({ message: 'License plate not found' });
    }

    // Keep the existing userId when updating
    const validatedData = await plateSchema.validate({
      ...req.body,
      userId: plate.userId // Preserve the existing userId
    });
    const updatedPlate = await plate.update({
      ...validatedData,
      userId: plate.userId // Ensure userId remains unchanged
    });
    
    // Fetch updated plate with user details
    const plateWithUser = await Plate.findByPk(updatedPlate.id, {
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }]
    });
    
    console.log('[Update Plate] Plate updated:', plateWithUser.toJSON());
    res.json({
      message: 'License plate updated successfully',
      plate: plateWithUser
    });
  } catch (error) {
    console.error('[Update Plate] Error:', error);
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: error.message });
    }
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'License plate number already exists' });
    }
    res.status(500).json({ message: 'Server error' });
  }
};

exports.deletePlate = async (req, res) => {
  const { id } = req.params;
  try {
    console.log(`[Delete Plate] Request received for plate ${id}`);
    
    const plate = await Plate.findByPk(id);
    if (!plate) {
      return res.status(404).json({ message: 'License plate not found' });
    }

    await plate.destroy();
    console.log(`[Delete Plate] Plate ${id} deleted successfully`);
    res.json({ message: 'License plate deleted successfully' });
  } catch (error) {
    console.error('[Delete Plate] Error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getPlateById = async (req, res) => {
  const { id } = req.params;
  try {
    console.log(`[Get Plate] Request received for plate ${id}`);
    
    const plate = await Plate.findByPk(id, {
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }]
    });

    if (!plate) {
      return res.status(404).json({ message: 'License plate not found' });
    }
    
    console.log(`[Get Plate] Found plate ${id}`);
    res.json(plate);
  } catch (error) {
    console.error('[Get Plate] Error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
exports.uploadVehiclePhoto = async (req, res) => {
  const isCheckOut = req.body.type === 'checkout';
  
   const point=()=>{
    try {
      return JSON.parse(req.body.point);
    } catch (error) {
      return undefined
    }
   }

  try {
    // Validate required fields
    if (!req.body.plateId) {
      return res.status(400).json({ message: 'Vehicle plate ID is required' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'Vehicle photo is required' });
    }

    // Find the plate
    const plate = await Plate.findByPk(req.body.plateId);
    if (!plate) {
      return res.status(404).json({ message: 'License plate not found' });
    }

    // Check for active check-in
    // const activeCheckIn = await CheckIn.findOne({
    //   where: {
    //     plateId: plate.id,
    //     status: 'checked-in'
    //   },
    //   order: [['checkInTime', 'DESC']]
    // });

    // // Check-in validations
    // if (!isCheckOut && activeCheckIn) {
    //   return res.status(400).json({
    //     message: 'Vehicle already checked in. Check-out first.'
    //   });
    // }

    // // Check-out validations
    // if (isCheckOut && !activeCheckIn) {
    //   return res.status(400).json({
    //     message: 'No active check-in found. Check-in first.'
    //   });
    // }

    const relativePath = `uploads/${req.file.filename}`;
    let checkIn;

    if (isCheckOut) {
      // Update existing check-in with check-out details
      checkIn = await activeCheckIn.update({
        checkOutTime: new Date(),
        checkOutPhotoUrl: relativePath,
        checkedOutBy: req.user?.id,
        status: 'checked-out',
        notes: `Check-out completed for check-in ID: ${activeCheckIn.id}`
      });

      // Update plate to clear last check-in if needed (optional)
      await plate.update({
        lastCheckedInAt: null,
        lastCheckedInBy: null
      });
    } else {
      // Create new check-in
      checkIn = await CheckIn.create({
        plateId: plate.id,
        checkInTime: new Date(),
        location: req.body.location,
        point: point(),
        checkInPhotoUrl: relativePath,
        checkedInBy: req.user?.id,
        status: 'checked-in'
      });

      // Update plate with latest check-in info
      await plate.update({
        lastCheckedInAt: checkIn.checkInTime,
        lastCheckedInBy: req.user?.id
      });
    }

    // Fetch updated check-in record with associations
    const resultRecord = await CheckIn.findByPk(checkIn.id, {
      include: [
        { model: Plate, as: 'plate', include: [{ model: User, as: 'user' }] },
        { model: User, as: 'checkedInByUser' },
        { model: User, as: 'checkedOutByUser' }
      ]
    });

    res.status(200).json({
      message: isCheckOut ? 'Check-out successful' : 'Check-in successful',
      checkIn: resultRecord
    });

  } catch (error) {
    console.error('Error:', error);
    
    // Cleanup uploaded file on error
    if (req.file) {
      try {
        await fs.unlink(req.file.path);
      } catch (unlinkError) {
        console.error('File cleanup error:', unlinkError);
      }
    }

    res.status(500).json({
      message: isCheckOut ? 'Check-out failed' : 'Check-in failed',
      error: error.message
    });
  }
};

exports.getCurrentUserPlates = async (req, res) => {
  try {
    const userId = req.user.id;
    console.log(`[Get Current User Plates] Request received for user ${userId}`);
    
    if (!userId) {
      console.error('[Get Current User Plates] No user ID provided');
      return res.status(400).json({
        message: 'User ID is required',
        plates: []
      });
    }
    
    const plates = await Plate.findAll({
      where: { userId },
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }]
    });
    
    console.log(`[Get Current User Plates] Found ${plates?.length || 0} plates for user ${userId}`);
    
    if (!plates) {
      console.log('[Get Current User Plates] No plates found, returning empty array');
      return res.json({
        count: 0,
        plates: []
      });
    }
    
    // Convert Sequelize instances to plain objects
    const plainPlates = plates.map(plate => {
      if (!plate) return null;
      const plainPlate = plate.get({ plain: true });
      return {
        ...plainPlate,
        user: plainPlate.user || null
      };
    }).filter(plate => plate !== null);
    
    console.log('[Get Current User Plates] Response:', {
      count: plainPlates.length,
      plates: plainPlates
    });
    
    res.json({
      count: plainPlates.length,
      plates: plainPlates
    });
  } catch (error) {
    console.error('[Get Current User Plates] Error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get check-in/check-out logs for a specific plate
exports.getCheckInLogs = async (req, res) => {
  try {
    const { startDate, endDate, search } = req.query;
    console.log("search????????????????????",search)
    // Build date filter if dates are provided
    let dateFilter = {};
    if (startDate && endDate) {
      dateFilter.checkInTime = {
        [Op.between]: [new Date(startDate), new Date(endDate)]
      };
    }

    // Build the main where clause
    const whereClause = {
      ...dateFilter
    };

    // Build include conditions
    const include = [
      {
        model: Plate,
        as: 'plate',
        attributes: ['id', 'number', 'vehicleType'],
        include: [{
          model: User,
          as: 'user',
          attributes: ['id', 'username', 'email']
        }]
      },
      {
        model: User,
        as: 'checkedInByUser',
        attributes: ['id', 'username', 'email']
      },
      {
        model: User,
        as: 'checkedOutByUser',
        attributes: ['id', 'username', 'email']
      }
    ];

    // Add search filter if search term exists
    if (search) {
      include[0].where = {
        [Op.or]: [
          { number: { [Op.iLike]: `%${search}%` } },
          { vehicleType: { [Op.iLike]: `%${search}%` } }
        ]
      };
    }

    // Get check-in logs
    const logs = await CheckIn.findAll({
      where: whereClause,
      include: include,
      order: [['checkInTime', 'DESC']]
    });

    res.json({ logs });
  } catch (error) {
    console.error('[Get Check-in Logs] Error:', error);
    res.status(500).json({
      message: 'Failed to get check-in logs',
      error: error.message
    });
  }
};

// Get all check-in/check-out logs with filters
exports.getAllCheckInLogs = async (req, res) => {
  try {
    const { startDate, endDate, status, search } = req.query;
    const page = parseInt(req.query.page) || 0;
    const limit = parseInt(req.query.limit) || 10;

    // Build base where clause
    const where = {};
    
    // Date filter
    if (startDate && endDate) {
      where.checkInTime = {
        [Op.between]: [new Date(startDate), new Date(endDate)]
      };
    }

    // Status filter
    if (status) {
      where.status = status;
    }

    // Initialize search conditions
    let plateWhere = {};
    if (search) {
      const sanitizedSearch = search.trim().replace(/[%_]/g, '');
      const searchTerm = sanitizedSearch.toLowerCase()
      plateWhere = {
        [Op.or]: [
          Sequelize.where(
            Sequelize.fn('LOWER', Sequelize.col('plate.number')),
            Op.like, `%${searchTerm.toLowerCase()}%`
          ),
          Sequelize.where(
            Sequelize.fn('LOWER', Sequelize.col('plate.vehicleType')),
            Op.like, `%${searchTerm.toLowerCase()}%`
          )
        ]
      };
    }

    // Include configuration
    const include = [
      {
        model: Plate,
        as: 'plate',
        attributes: ['id', 'number', 'vehicleType', 'isUnregistered'],
        where: plateWhere,
        required: !!search, // Only require plates when searching
        include: [{
          model: User,
          as: 'user',
          attributes: ['id', 'username', 'email']
        }]
      },
      {
        model: User,
        as: 'checkedInByUser',
        attributes: ['id', 'username', 'email']
      },
      {
        model: User,
        as: 'checkedOutByUser',
        attributes: ['id', 'username', 'email']
      }
    ];

    // Use findAndCountAll for accurate pagination
    const { count, rows: logs } = await CheckIn.findAndCountAll({
      where,
      include,
      distinct: true, // Crucial for correct count
      order: [['checkInTime', 'DESC']],
      limit,
      offset: page * limit
    });

    res.json({
      count,
      logs
    });
  } catch (error) {
    console.error('[Get All Check-in Logs] Error:', error);
    res.status(500).json({
      message: 'Failed to get check-in logs',
      error: error.message
    });
  }
};

// Create a temporary plate for unregistered vehicle
// Create a temporary plate for unregistered vehicle with transactions
exports.createTemporaryPlate = async (req, res) => {
  const t = await db.sequelize.transaction();
  try {
    const { number, vehicleType = "truck", Name = "", Phone = "", CompanyName = "", MakeModel = "", Color = "" } = req.body;

    if (!req?.file) {
      return res.status(400).json({ message: 'Vehicle photo is required' });
    }
    const relativePath = `uploads/${req.file.filename}`;

    // Validate required fields
    if (!number || !vehicleType) {
      return res.status(400).json({ message: 'Required fields missing' });
    }

    // Check if plate already exists
    const existingPlate = await Plate.findOne({ where: { number }, transaction: t });
    if (existingPlate) {
      await t.rollback();
      return res.status(400).json({ message: 'License plate already exists' });
    }

    // Create temporary plate
    const plate = await Plate.create({
      number,
      vehicleType,
      Name,
      Phone,
      CompanyName,
      MakeModel,
      Color,
      isUnregistered: true,
      checkInTime: new Date(),
      checkInPhotoUrl: relativePath,
      checkedInBy: req.user?.id,
      userId: req.user?.id,
      status: 'active'
    }, { transaction: t });

    const checkIn = await CheckIn.create({
      plateId: plate.id,
      checkInTime: new Date(),
      checkInPhotoUrl: relativePath,
      checkedInBy: req.user?.id,
      status: 'checked-in'
    }, { transaction: t });

    // Update plate with latest check-in info
    await plate.update({
      lastCheckedInAt: checkIn.checkInTime,
      lastCheckedInBy: req.user?.id
    }, { transaction: t });

    // Commit transaction
    await t.commit();
    const response = {
      message: 'Temporary plate created successfully',
      plate: {
        ...plate.toJSON(),
        checkIn
      }
    };
    res.status(201).json(response);
  } catch (error) {
    await t.rollback();
    console.error('[Create Temporary Plate] Error:', error);
    res.status(500).json({ message: 'Failed to create temporary plate', error: error.message });
  }
};

