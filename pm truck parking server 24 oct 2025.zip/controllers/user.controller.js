const yup = require('yup');
const bcrypt = require('bcryptjs');
const db = require('../models');
const { Op, where, Sequelize } = require('sequelize');

const createUserSchema = yup.object().shape({
  username: yup.string().min(3).max(50).required(),
  email: yup.string().email().required(),
  password: yup.string().min(6).required(),
  role: yup.string().oneOf(['user', 'admin']).default('user'),
  status: yup.string().oneOf(['active', 'inactive']).default('active')
});

const updateUserSchema = yup.object().shape({
  username: yup.string().min(3).max(50),
  email: yup.string().email(),
  password: yup.string().min(6),
  role: yup.string().oneOf(['user', 'admin']),
  status: yup.string().oneOf(['active', 'inactive'])
});

// Helper function to safely convert Sequelize instance to JSON
const safeUserResponse = (user) => {
  if (!user) return null;
  const userData = user.get({ plain: true });
  delete userData.password;
  return userData;
};

exports.createUser = async (req, res) => {
  try {
    console.log('[Users] Create request received:', req.body);
    
    // Validate request body
    const validatedData = await createUserSchema.validate(req.body);
    console.log('[Users] Data validated successfully');
    
    // Create user
    const user = await db.users.create(validatedData);
    console.log('[Users] User created:', user.id);
    
    // Fetch the created user with associations
    const createdUser = await db.users.findByPk(user.id, {
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status']
      }]
    });
    
    if (!createdUser) {
      throw new Error('User created but could not be fetched');
    }
    
    res.status(201).json({
      message: 'User created successfully',
      user: createdUser.toJSON()
    });
  } catch (error) {
    console.error('[Users] Create error:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        message: 'Validation error',
        errors: error.errors 
      });
    }
    
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ 
        message: 'Email or username already exists',
        errors: error.errors
      });
    }
    
    res.status(500).json({ 
      message: 'Server error during user creation',
      error: error.message 
    });
  }
};

exports.getCurrentUser = async (req, res) => {
  try {
    const userId = req.user.id;
    console.log('[Users] Getting current user profile:', userId);

    const user = await db.users.findByPk(userId, {
      attributes: { exclude: ['password'] },
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status', 'createdAt', 'updatedAt']
      }]
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(safeUserResponse(user));
  } catch (error) {
    console.error('[Users] Get current user error:', error);
    res.status(500).json({
      message: 'Error fetching user profile',
      error: error.message
    });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    console.log('[Users] Getting user by id:', id);

    const user = await db.users.findByPk(id, {
      attributes: { exclude: ['password'] },
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status', 'createdAt', 'updatedAt']
      }]
    });

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(safeUserResponse(user));
  } catch (error) {
    console.error('[Users] Get user by id error:', error);
    res.status(500).json({
      message: 'Error fetching user',
      error: error.message
    });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    console.log('[Users] Getting all users...');
    const whereCluse={}
    if(req.body.search){
      const search= req.body.search.trim();
      const sanitizedSearch = search.trim().replace(/[%_]/g, '');
      const searchTerm = sanitizedSearch.toLowerCase()
      whereCluse[Op.or] = [
        Sequelize.where(
          Sequelize.fn('LOWER', Sequelize.col('username')),
          { [Op.like]: `%${searchTerm}%` }
        ),
        Sequelize.where(
          Sequelize.fn('LOWER', Sequelize.col('email')),
          { [Op.like]: `%${searchTerm}%` }
        )
      ]
    }
    if(req.body.role){
      whereCluse.role = req.body.role;
    }
    if(req.body.status){
      whereCluse.status = req.body.status;
    }
  
    const users = await db.users.findAll({
      where: whereCluse,
      attributes: { exclude: ['password'] },
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status', 'createdAt', 'updatedAt']
      }],
      order: [['createdAt', 'DESC']]
    });

    const safeUsers = users.map(safeUserResponse);

    console.log(`[Users] Found ${safeUsers.length} users`);
    res.json({
      count: safeUsers.length,
      users: safeUsers
    });
  } catch (error) {
    console.error('[Users] Error getting users:', error);
    res.status(500).json({ 
      message: 'Error fetching users',
      error: error.message 
    });
  }
};
exports.getRolesAndStatus = async (req, res) => {
  try {
    console.log('[Users] Getting roles and status...');
    const roles = await db.users.aggregate('role', 'DISTINCT', { plain: false });
    const status = await db.users.aggregate('status', 'DISTINCT', { plain: false });

    console.log('[Users] Roles:', roles);
    console.log('[Users] Status:', status);
    res.json({ roles, status });
  } catch (error) {
    console.error('[Users] Error getting roles and status:', error);
    res.status(500).json({ 
      message: 'Error fetching roles and status',
      error: error.message 
    });
  }
}

exports.updateUser = async (req, res) => {
  const { id } = req.params;
  try {
    console.log(`[Users] Update request for user ${id}:`, req.body);
    
    // Validate request body
    const validatedData = await updateUserSchema.validate(req.body);
    
    // Find user with associations
    const user = await db.users.findByPk(id, {
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status']
      }]
    });
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update user
    await user.update(validatedData);
    
    // Refresh user data
    await user.reload();
    
    console.log(`[Users] User ${id} updated successfully`);
    res.json({
      message: 'User updated successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error(`[Users] Error updating user ${id}:`, error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        message: 'Validation error',
        errors: error.errors 
      });
    }
    
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ 
        message: 'Email or username already exists',
        errors: error.errors
      });
    }
    
    res.status(500).json({ 
      message: 'Server error during user update',
      error: error.message 
    });
  }
};

exports.deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    console.log(`[Users] Delete request for user ${id}`);
    
    const user = await db.users.findByPk(id, {
      include: [{
        model: db.plates,
        as: 'plates'
      }]
    });
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Delete user (plates will be deleted automatically due to CASCADE)
    await user.destroy();
    
    console.log(`[Users] User ${id} deleted successfully`);
    res.json({ 
      message: 'User deleted successfully',
      userId: id
    });
  } catch (error) {
    console.error(`[Users] Error deleting user ${id}:`, error);
    res.status(500).json({ 
      message: 'Server error during user deletion',
      error: error.message 
    });
  }
};
