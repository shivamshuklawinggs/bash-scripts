const db = require('../models');
const User = db.user;
const Plate = db.plate;

exports.getDashboardData = async (req, res) => {
  try {
    console.log('[Dashboard] Getting dashboard data');
    const userId = req.user.id;

    // Get user's plates count
    const userPlatesCount = await Plate.count({
      where: { userId }
    });

    // Get total plates count (admin only)
    let totalPlatesCount = 0;
    if (req.user.role === 'admin') {
      totalPlatesCount = await Plate.count();
    }

    // Get recent plates (last 5)
    const recentPlates = await Plate.findAll({
      where: req.user.role === 'admin' ? {} : { userId },
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }],
      order: [['createdAt', 'DESC']],
      limit: 5
    });

    // Get plates by vehicle type
    const platesByType = await Plate.findAll({
      where: req.user.role === 'admin' ? {} : { userId },
      attributes: [
        'vehicleType',
        [db.sequelize.fn('COUNT', db.sequelize.col('id')), 'count']
      ],
      group: ['vehicleType']
    });

    // Get plates by status
    const platesByStatus = await Plate.findAll({
      where: req.user.role === 'admin' ? {} : { userId },
      attributes: [
        'status',
        [db.sequelize.fn('COUNT', db.sequelize.col('id')), 'count']
      ],
      group: ['status']
    });

    const dashboardData = {
      userPlatesCount,
      totalPlatesCount: req.user.role === 'admin' ? totalPlatesCount : null,
      recentPlates,
      platesByType: platesByType.reduce((acc, curr) => {
        acc[curr.vehicleType] = parseInt(curr.getDataValue('count'));
        return acc;
      }, {}),
      platesByStatus: platesByStatus.reduce((acc, curr) => {
        acc[curr.status] = parseInt(curr.getDataValue('count'));
        return acc;
      }, {})
    };

    console.log('[Dashboard] Dashboard data:', dashboardData);
    res.json(dashboardData);
  } catch (error) {
    console.error('[Dashboard] Error:', error);
    res.status(500).json({ 
      message: 'Failed to load dashboard data',
      error: {
        name: error.name,
        message: error.message
      }
    });
  }
};
