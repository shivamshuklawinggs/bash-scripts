const auth = require('./auth');

module.exports = {
  authJwt: auth
}; 