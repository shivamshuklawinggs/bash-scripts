const jwt = require('jsonwebtoken');
const config = require('../config/auth.config');
const db = require('../models');
const User = db.users;

const verifyToken = async (req, res, next) => {
  try {
    console.log("[Auth Middleware] Verifying token", config);
    const token = req.headers['x-access-token'] || req.headers['authorization']?.split(' ')[1];

    if (!token) {
      console.error("[Auth Middleware] No token provided");
      return res.status(403).json({
        message: 'No token provided'
      });
    }

    try {
      const decoded = jwt.verify(token, config.secret);
      console.log("[Auth Middleware] Token decoded successfully:", decoded);
      req.user = decoded;

      // Verify user exists in database
      const user = await User.findByPk(decoded.id);
      if (!user) {
        console.error("[Auth Middleware] User not found in database");
        return res.status(401).json({
          message: 'User not found'
        });
      }

      next();
    } catch (jwtError) {
      console.error("[Auth Middleware] JWT verification failed:", jwtError.message);
      return res.status(401).json({
        message: 'Invalid token'
      });
    }
  } catch (error) {
    console.error('[Auth Middleware] Unexpected error:', error);
    return res.status(500).json({
      message: 'Internal server error'
    });
  }
};

const isAdmin = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id);
    if (!user) {
      return res.status(401).json({
        message: 'User not found'
      });
    }

    if (user.role !== 'admin') {
      return res.status(403).json({
        message: 'Require Admin Role!'
      });
    }
    next();
  } catch (error) {
    console.error('[Auth Middleware] Error:', error);
    return res.status(500).json({
      message: 'Unable to validate user role'
    });
  }
};

module.exports = {
  verifyToken,
  isAdmin
};