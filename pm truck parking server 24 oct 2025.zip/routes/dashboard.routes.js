const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middleware/auth');
const db = require('../models');
const { Op } = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     DashboardStats:
 *       type: object
 *       properties:
 *         user:
 *           type: object
 *         totalVehicles:
 *           type: integer
 *         vehicleTypes:
 *           type: object
 *           properties:
 *             car:
 *               type: integer
 *             truck:
 *               type: integer
 *         status:
 *           type: object
 *           properties:
 *             active:
 *               type: integer
 *             inactive:
 *               type: integer
 *         recentPlates:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               id:
 *                 type: integer
 *               number:
 *                 type: string
 *               vehicleType:
 *                 type: string
 *               status:
 *                 type: string
 *               createdAt:
 *                 type: string
 *               updatedAt:
 *                 type: string
 *               user:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: integer
 *                   name:
 *                     type: string
 *                   email:
 *                     type: string
 *                   role:
 *                     type: string
 */

// Apply authentication middleware to all routes
router.use(verifyToken);

/**
 * @swagger
 * /api/dashboard/stats:
 *   get:
 *     summary: Get dashboard statistics
 *     tags: [Dashboard]
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Dashboard statistics
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DashboardStats'
 */
router.get('/stats', async (req, res) => {
  try {
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';

    // Base query conditions for plates
    const plateCondition = isAdmin ? {} : { userId };

    // Log debugging info
    console.log('[Dashboard] User:', { id: userId, role: req.user.role });
    console.log('[Dashboard] Plate condition:', plateCondition);

    // Get current user with their plates
    const currentUser = await db.users.findByPk(userId, {
      attributes: { exclude: ['password'] },
      include: [{
        model: db.plates,
        as: 'plates',
        attributes: ['id', 'number', 'vehicleType', 'status', 'createdAt', 'updatedAt']
      }]
    });

    if (!currentUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get plate statistics
    const [
      totalVehicles,
      carCount,
      truckCount,
      activePlates,
      inactivePlates
    ] = await Promise.all([
      db.plates.count({ where: plateCondition }),
      db.plates.count({ where: { ...plateCondition, vehicleType: 'car' } }),
      db.plates.count({ where: { ...plateCondition, vehicleType: 'truck' } }),
      db.plates.count({ where: { ...plateCondition, status: 'active' } }),
      db.plates.count({ where: { ...plateCondition, status: 'inactive' } })
    ]);

    // Get recent plates
    const recentPlates = await db.plates.findAll({
      where: plateCondition,
      include: [{
        model: db.users,
        as: 'user',
        attributes: { exclude: ['password'] }
      }],
      order: [['createdAt', 'DESC']],
      limit: 5
    });

    // Convert plates to plain objects
    const plainPlates = recentPlates.map(plate => {
      const plainPlate = plate.get({ plain: true });
      if (plainPlate.user) {
        delete plainPlate.user.password;
      }
      return plainPlate;
    });

    // Prepare response
    const stats = {
      user: currentUser.get({ plain: true }),
      totalVehicles,
      vehicleTypes: {
        car: carCount,
        truck: truckCount
      },
      status: {
        active: activePlates,
        inactive: inactivePlates
      },
      recentPlates: plainPlates
    };

    // Add admin-only statistics
    if (isAdmin) {
      const [totalUsers, activeUsers] = await Promise.all([
        db.users.count(),
        db.users.count({ where: { status: 'active' } })
      ]);

      stats.users = {
        total: totalUsers,
        active: activeUsers
      };
    }

    console.log('[Dashboard] Stats prepared successfully');
    res.json(stats);
  } catch (error) {
    console.error('[Dashboard] Error:', error);
    res.status(500).json({ 
      message: 'Error fetching dashboard statistics',
      error: error.message
    });
  }
});

/**
 * @swagger
 * /api/dashboard/recent-activity:
 *   get:
 *     summary: Get recent check-in/check-out activity
 *     tags: [Dashboard]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of records to return
 *     responses:
 *       200:
 *         description: Recent activity list
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: integer
 *                   number:
 *                     type: string
 *                   vehicleType:
 *                     type: string
 *                   status:
 *                     type: string
 *                   createdAt:
 *                     type: string
 *                   updatedAt:
 *                     type: string
 *                   user:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: integer
 *                       name:
 *                         type: string
 *                       email:
 *                         type: string
 *                       role:
 *                         type: string
 */
router.get('/activity', async (req, res) => {
  try {
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';

    // Get current user
    const currentUser = await db.users.findByPk(userId, {
      attributes: { exclude: ['password'] }
    });

    if (!currentUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Get recent plates
    const recentPlates = await db.plates.findAll({
      where: isAdmin ? {} : { userId },
      include: [{
        model: db.users,
        as: 'user',
        attributes: { exclude: ['password'] }
      }],
      order: [['createdAt', 'DESC']],
      limit: 10
    });

    // Convert to plain objects
    const plainPlates = recentPlates.map(plate => {
      const plainPlate = plate.get({ plain: true });
      if (plainPlate.user) {
        delete plainPlate.user.password;
      }
      return plainPlate;
    });

    const activity = {
      user: currentUser.get({ plain: true }),
      plates: plainPlates
    };

    console.log('[Dashboard] Activity prepared successfully');
    res.json(activity);
  } catch (error) {
    console.error('[Dashboard] Error:', error);
    res.status(500).json({ 
      message: 'Error fetching recent activity',
      error: error.message
    });
  }
});

module.exports = router;