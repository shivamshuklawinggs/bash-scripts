const express = require('express');
const router = express.Router();
const plateController = require('../controllers/plate.controller');
const { authJwt } = require('../middleware');
const upload = require('../utils/upload');

// Create uploads directory if it doesn't exist
const fs = require('fs');
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}
/**
 * @swagger
 * components:
 *   schemas:
 *     Plate:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *         number:
 *           type: string
 *         vehicleType:
 *           type: string
 *           enum: [car, truck]
 *         status:
 *           type: string
 *           enum: [active, inactive]
 *     CheckIn:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *         plateId:
 *           type: integer
 *         checkInPhotoUrl:
 *           type: string
 *         location:
 *           type: string
 *         point:
 *           type: object
 *     TemporaryPlate:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *         number:
 *           type: string
 *         vehicleType:
 *           type: string
 *           enum: [car, truck]
 *         photoUrl:
 *           type: string
 */


// Apply authentication middleware to all routes
router.use(authJwt.verifyToken);

/**
 * @swagger
 * /api/plates:
 *   get:
 *     summary: Get all plates
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: List of all plates
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 count:
 *                   type: integer
 *                 plates:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Plate'
 */
router.get('/', plateController.getAllPlates); // All users can see all plates

/**
 * @swagger
 * /api/plates/my-plates:
 *   get:
 *     summary: Get current user's plates
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: List of user's plates
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Plate'
 */
router.get('/my-plates', plateController.getCurrentUserPlates); // Get user's plates

/**
 * @swagger
 * /api/plates/check-in:
 *   post:
 *     summary: Check in a vehicle with photo
 *     tags: [Check-in/Check-out]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               plateId:
 *                 type: integer
 *               photo:
 *                 type: string
 *                 format: binary
 *               location:
 *                 type: string
 *                 description: Optional location description
 *               point:
 *                 type: object
 *                 properties:
 *                   type:
 *                     type: string
 *                     enum: [Point]
 *                   coordinates:
 *                     type: array
 *                     items:
 *                       type: number
 *                     description: [longitude, latitude]
 *     responses:
 *       200:
 *         description: Vehicle checked in successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CheckIn'
 */
router.post('/check-in', upload.single('photo'), plateController.uploadVehiclePhoto);


/**
 * @swagger
 * /api/plates/checkin-logs:
 *   get:
 *     summary: Get all check-in logs
 *     tags: [Check-in/Check-out]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [checked-in, checked-out]
 *     responses:
 *       200:
 *         description: All check-in logs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 count:
 *                   type: integer
 *                 logs:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/CheckIn'
 */
router.get('/checkin-logs', plateController.getAllCheckInLogs);

// Admin routes
/**
 * @swagger
 * /api/plates:
 *   post:
 *     summary: Create a new plate (Admin only)
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Plate'
 *     responses:
 *       201:
 *         description: Plate created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Plate'
 */
router.post('/', authJwt.isAdmin, plateController.createPlate); // Admin can create plates

/**
 * @swagger
 * /api/plates/{id}:
 *   get:
 *     summary: Get a plate by id
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Plate details
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Plate'
 */
router.get('/:id', plateController.getPlateById);

/**
 * @swagger
 * /api/plates/{plateId}/logs:
 *   get:
 *     summary: Get check-in logs for a specific plate
 *     tags: [Check-in/Check-out]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: plateId
 *         required: true
 *         schema:
 *           type: integer
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *     responses:
 *       200:
 *         description: Check-in logs for the plate
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 plateNumber:
 *                   type: string
 *                 logs:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/CheckIn'
 */
router.get('/:plateId/logs', plateController.getCheckInLogs);

/**
 * @swagger
 * /api/plates/temporary:
 *   post:
 *     summary: Create a temporary plate for unregistered vehicle
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - number
 *               - vehicleType
 *             properties:
 *               number:
 *                 type: string
 *               vehicleType:
 *                 type: string
 *               photo:
 *                 type: string
 *                 format: binary
 *     responses:
 *       201:
 *         description: Temporary plate created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TemporaryPlate'
 */
router.post('/temporary',upload.single('photo'), [authJwt.verifyToken], plateController.createTemporaryPlate);

/**
 * @swagger
 * /api/plates/{id}:
 *   put:
 *     summary: Update a plate (Admin only)
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Plate'
 *     responses:
 *       200:
 *         description: Plate updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Plate'
 */
router.put('/:id', authJwt.isAdmin, plateController.updatePlate);

/**
 * @swagger
 * /api/plates/{id}:
 *   delete:
 *     summary: Delete a plate (Admin only)
 *     tags: [Plates]
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Plate deleted successfully
 */
router.delete('/:id', authJwt.isAdmin, plateController.deletePlate);

module.exports = router;
