const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { verifyToken, isAdmin } = require('../middleware/auth');

// Apply authentication middleware to all routes
router.use(verifyToken);

// Get current user's profile
router.get('/profile', userController.getCurrentUser);

// Admin-only routes
router.use(isAdmin);

// User management routes (admin only)
router.get('/', userController.getAllUsers);
router.get('/rolesandstatus', userController.getRolesAndStatus);
router.post('/', userController.createUser);
router.get('/:id', userController.getUserById);
router.put('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);

// Error handling middleware
router.use((err, req, res, next) => {
  console.error('[Users] Route error:', err);
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    path: req.path
  });
});

module.exports = router;
