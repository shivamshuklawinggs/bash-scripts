import React, { useEffect, useState } from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Button, Dialog, DialogActions, DialogContent, DialogTitle,
  TextField, IconButton
} from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';
import { paymentAPI } from '../services/api';
import PaymentFom from './PaymentFom';
import { toast } from 'react-toastify';
import PaymentDetails from '../components/PaymentDetails';
import { formatCurrency } from '../utils';

const PaymentPage = () => {
  const [payments, setPayments] = useState([]);
  const [open, setOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [selectedPaymentId, setSelectedPaymentId] = useState(null);
  const [paymentDetails, setPaymentDetails] = useState(null);

  const [formData, setFormData] = useState({
    plateId: '',
    totalamount: '',
    paidAmount: '',
    amount: '',
    paymentMethod: '',
    paymentDate: new Date(),
    status: '',
    party: '',
    notes: ''
  });

  useEffect(() => {
    fetchPayments();
  }, []);
 const handleOpenDetails = (payment) => {
    setPaymentDetails(payment);
  };

  const handleCloseDetails = () => {
    setPaymentDetails(null);
  };
  const fetchPayments = async () => {
    const res = await paymentAPI.getPayments();
    console.log("fetchPayments response:", res.data);
    setPayments(res.data?.data || []);
  };

  const handleOpen = (payment = null) => {
    if (payment) {
        const dueamont=payment.totalAmount - payment.paidAmount;
        const data={
          ...payment,
          amount: dueamont,
         
        }
      setFormData(data);
      setSelectedPaymentId(payment.id);
      setIsEdit(true);
    } else {
      setFormData({
        plateId: '',
        totalamount: '',
        paidAmount: '',
        amount: '',
        paymentMethod: '',
        paymentDate: new Date(),
        status: '',
        party: '',
        notes: ''
      });
      setIsEdit(false);
      setSelectedPaymentId(null);
    }
    setOpen(true);
  };

  const handleClose = () => setOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
   
      setFormData((prev) => ({ ...prev, [name]: value }));
    
  };

  const handleDataChange = (name, date) => {
    handleChange((prev) => ({ ...prev, [name]: date }));
  };

  const handleSubmit = async () => {
    try {
      if (isEdit) {
        await paymentAPI.updatePayment(selectedPaymentId, formData);
      } else {
        await paymentAPI.createPayment(formData);
      }
      fetchPayments();
      handleClose();
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Failed to save payment');
      console.error(err);
    }
  };

  const handleDelete = async (id) => {
    await paymentAPI.deletePayment(id);
    fetchPayments();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Payments</h2>
      <Button variant="contained" color="primary" onClick={() => handleOpen()}>
        Add Payment
      </Button>

      <TableContainer component={Paper} style={{ marginTop: 20 }}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Plate ID</TableCell>
              <TableCell>Total</TableCell>
              <TableCell>Paid</TableCell>
              <TableCell>Last Paid Amount</TableCell>
              <TableCell>Method</TableCell>
              <TableCell>Date</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Party</TableCell>
              <TableCell>Notes</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {payments?.map((p) => (
              <TableRow key={p.id}>
                <TableCell>{p?.plateId}</TableCell>
                <TableCell>{formatCurrency(p?.totalAmount || 0)}</TableCell>
                <TableCell>
                  <Button 
                            variant="text" 
                            color="primary" 
                            onClick={() => handleOpenDetails(p)}
                            sx={{ p: 0 }}
                          >
                            {formatCurrency(p?.paidAmount || 0)}
                          </Button>
                </TableCell>
                
                <TableCell>{formatCurrency(p?.amount || 0)}</TableCell>
                <TableCell>{p?.paymentMethod}</TableCell>
                <TableCell>{new Date(p?.paymentDate).toLocaleDateString()}</TableCell>
                <TableCell>{p?.status}</TableCell>
                <TableCell>{p?.party}</TableCell>
                <TableCell>{p?.notes}</TableCell>
                <TableCell>
                  <IconButton onClick={() => handleOpen(p)}><Edit /></IconButton>
                  <IconButton onClick={() => handleDelete(p?.id)}><Delete /></IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

      </TableContainer>

      <PaymentFom open={open} handleClose={handleClose} isEdit={isEdit} formData={formData} handleChange={handleChange} handleSubmit={handleSubmit} handleDataChange={handleDataChange} />
         {/* Payment Details Dialog */}
      <PaymentDetails
        handleClose={handleCloseDetails}
        payment={paymentDetails}
      />
    </div>
  );
};

export default PaymentPage;
