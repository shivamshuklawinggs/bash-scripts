import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import {
  Container,
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Alert,
  CircularProgress
} from '@mui/material';
import { authAPI } from '../services/api';
import { loginSuccess, loginFailure, clearError } from '../store/slices/authSlice';

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Clear any previous errors when component mounts
    dispatch(clearError());
    // Clear local error state
    setError('');
  }, [dispatch]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.email || !formData.password) {
      setError('Please enter both email and password');
      return;
    }

    setLoading(true);
    setError('');
    dispatch(clearError());

    try {
      const response = await authAPI.login(formData);
      console.log('Login response:', response.data);
      
      if (response.data && response.data.token) {
        dispatch(loginSuccess(response.data));
        navigate('/dashboard');
      } else {
        throw new Error('Invalid response from server');
      }
    } catch (err) {
      console.error('Login error:', err);
      const errorMessage = err.response?.data?.message || 'Login failed. Please try again.';
      setError(errorMessage);
      dispatch(loginFailure(errorMessage));
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (type) => {
    setLoading(true);
    setError('');
    dispatch(clearError());
    
    const credentials = type === 'admin' 
      ? { email: 'admin@example.com', password: 'admin123' }
      : { email: 'test@example.com', password: 'test123' };

    try {
      const response = await authAPI.login(credentials);
      console.log('Quick login response:', response.data);
      
      if (response.data && response.data.token) {
        dispatch(loginSuccess(response.data));
        navigate('/dashboard');
      } else {
        throw new Error('Invalid response from server');
      }
    } catch (err) {
      console.error('Quick login error:', err);
      const errorMessage = err.response?.data?.message || 'Login failed. Please try again.';
      setError(errorMessage);
      dispatch(loginFailure(errorMessage));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container maxWidth="sm">
      <Box sx={{ 
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        py: 3
      }}>
        <Paper elevation={3} sx={{ p: 4, width: '100%' }}>
          <Typography variant="h4" component="h1" align="center" color="primary" gutterBottom>
            Parking App Login
          </Typography>

          {error && (
            <Alert severity="error" sx={{ mb: 3 }}>
              {error}
            </Alert>
          )}

          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              margin="normal"
              required
              disabled={loading}
            />
            <TextField
              fullWidth
              label="Password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              margin="normal"
              required
              disabled={loading}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="primary"
              size="large"
              disabled={loading}
              sx={{ mt: 3 }}
            >
              {loading ? <CircularProgress size={24} /> : 'Login'}
            </Button>
          </form>

          {/* <Box sx={{ mt: 4, mb: 2 }}>
            <Typography variant="body1" align="center" gutterBottom>
              Quick Login Options:
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center' }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => handleQuickLogin('admin')}
                disabled={loading}
              >
                Admin Login
              </Button>
              <Button
                variant="outlined"
                color="secondary"
                onClick={() => handleQuickLogin('user')}
                disabled={loading}
              >
                User Login
              </Button>
            </Box>
          </Box> */}

          {/* <Typography variant="caption" display="block" align="center" color="textSecondary">
            Admin: admin@example.com / admin123<br />
            User: test@example.com / test123
          </Typography> */}
        </Paper>
      </Box>
    </Container>
  );
};

export default Login;
