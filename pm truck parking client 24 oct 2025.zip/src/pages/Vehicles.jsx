import React, { useEffect, useState,useCallback } from 'react';
import { useSelector } from 'react-redux';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  IconButton,
  Typography,
  Grid ,
  TextField ,
  InputAdornment ,
  TablePagination,
  CircularProgress,
  Alert,
  Snackbar
} from '@mui/material';
import {
  Delete as DeleteIcon,
  Add as AddIcon,
  PhotoCamera as PhotoIcon,
  Edit as EditIcon
} from '@mui/icons-material';
import { URL, vehicleAPI } from '../services/api';
import VehicleForm from '../components/VehicleForm';
import getCurrentLocation from '../utils/getCurentLocation';
import PhotoModel from '../components/PhotoModel';
import SearchIcon from '@mui/icons-material/Search';
import { debounce } from 'lodash';

const Vehicles = () => {
  const { user } = useSelector(state => state.auth);
  const [vehicles, setVehicles] = useState([]);
  const [totalVehicles, setTotalVehicles] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

      const [page, setPage] = useState(0);
      const [rowsPerPage, setRowsPerPage] = useState(10);
      const [totalCount, setTotalCount] = useState(0);
      const [filters, setFilters] = useState({
        status: '',
        search: '',
      });
  
      console.log("page",page)
  const handleImageClick = (photoUrl) => {
    setSelectedImage(`${URL}${photoUrl}`);
  };

  const handleCloseImage = () => {
    setSelectedImage(null);
  };
  const fetchVehicles = async () => {
    try {
      const params = {
        page: page,
        limit: rowsPerPage,
        ...filters,
      };
      
      console.log("🚀 Sending API request with params:", params); // Debug log

      setLoading(true);
      const response = await vehicleAPI.getAllVehicles({ params });
    
      console.log("✅ API Response:", response.data); // Debug log
      if(response.data){
        setVehicles(response.data.plates);
        setTotalVehicles(response.data.total);
        setTotalCount(response.data.total || 0);
      }
    
    } catch (error) {
      console.error('Error fetching vehicles:', error);
      setTotalCount(0);
      setError('Failed to load vehicles. Please try again later.');
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Failed to load vehicles',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };



      const debouncedFetchUsers = useCallback(
        debounce(() => {
          fetchVehicles();
        }, 600), // 300ms delay
        [filters, page, rowsPerPage]
      );
      
      useEffect(() => {
        debouncedFetchUsers();
        return () => debouncedFetchUsers.cancel(); // Cleanup function
      }, [filters, page, rowsPerPage]);

  const handleOpenDialog = (vehicle = null) => {
    setSelectedVehicle(vehicle);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    // First close the dialog
    setDialogOpen(false);
    // Then reset the selected vehicle after a short delay
    // This prevents form flicker during dialog close animation
    setTimeout(() => {
      setSelectedVehicle(null);
    }, 300);
  };

  const handleSubmit = async (formData) => {
    try {
      setLoading(true);
      const data={
        ...formData,
        Rent: Number(formData.Rent),
      }

      if (selectedVehicle?.id) {
        // Update existing vehicle
        console.log('Updating vehicle:', selectedVehicle.id, data);
        await vehicleAPI.updateVehicle(selectedVehicle.id, data);
        setSnackbar({
          open: true,
          message: 'Vehicle updated successfully',
          severity: 'success'
        });
      } else {
        // Create new vehicle
        console.log('Creating new vehicle:', data);
        await vehicleAPI.createVehicle(data);
        setSnackbar({
          open: true,
          message: 'Vehicle created successfully',
          severity: 'success'
        });
      }
      handleCloseDialog();
      fetchVehicles();
    } catch (error) {
      setLoading(false);
      console.error('Operation failed:', error.response?.data || error);
      setSnackbar({
        open: true,
        message: error.response?.data?.message || 'Operation failed',
        severity: 'error'
      });
    }finally{
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this vehicle?')) {
      try {
        await vehicleAPI.deleteVehicle(id);
        setSnackbar({
          open: true,
          message: 'Vehicle deleted successfully',
          severity: 'success'
        });
        fetchVehicles();
      } catch (error) {
        setSnackbar({
          open: true,
          message: 'Failed to delete vehicle',
          severity: 'error'
        });
      }
    }
  };
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };
  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
    setPage(0);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '60vh'
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ mb: 1 }}>Vehicle Database</Typography>
          <Typography variant="body2" color="text.secondary">
            All registered vehicles in the system
          </Typography>
        </Box>
        {user?.role === 'admin' && (
          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={handleOpenDialog}
          >
            Add New Vehicle
          </Button>
        )}
      </Box>
      <Grid item xs={12} md={3}>
                  <TextField
                    label="Search"
                    value={filters.search}
                    onChange={(e) => handleFilterChange('search', e.target.value)}
                    placeholder="Search by plate number or vehicle type"
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon />
                        </InputAdornment>
                      ),
                    }}
                  />
         </Grid>
      

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>License Plate</TableCell>
              <TableCell>Vehicle Type</TableCell>
              <TableCell>Company Name</TableCell>
              <TableCell>Company Owner Name</TableCell>
              <TableCell>Company Phone</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Make/Model</TableCell>
              <TableCell>Color</TableCell>
              <TableCell>Rent</TableCell>
              <TableCell>Remote</TableCell>
              <TableCell>Remote Number</TableCell>
              {/* <TableCell>Last Check-in</TableCell> */}
              {/* <TableCell>Location</TableCell> */}
              {user?.role === 'admin' && <TableCell>Actions</TableCell>}
            </TableRow>
          </TableHead>
          <TableBody>
            {vehicles.map((vehicle) => (
              <TableRow key={vehicle.id}>
                <TableCell>{vehicle.number}</TableCell>
                <TableCell>{vehicle.vehicleType}</TableCell>
                <TableCell>{vehicle.CompanyName}</TableCell>
                <TableCell>{vehicle.Name}</TableCell>
                <TableCell>{vehicle.Phone}</TableCell>
                <TableCell>{vehicle.Email}</TableCell>
                <TableCell>{vehicle.MakeModel}</TableCell>
                <TableCell>{vehicle.Color}</TableCell>
                <TableCell>{formatCurrency(vehicle.Rent)}</TableCell>
                <TableCell>{vehicle.Remote ? 'Yes' : 'No'}</TableCell>
                <TableCell>{vehicle.Remote ? vehicle.RemoteNumber : 'N/A'}</TableCell>
                {/* <TableCell>{vehicle.isUnregistered ? 'Yes' : 'No'}</TableCell> */}

                {/* <TableCell>
                  {vehicle.lastCheckedInAt 
                    ? new Date(vehicle.lastCheckedInAt).toLocaleString()
                    : 'Not checked in yet'}
                </TableCell> */}
                {/* <TableCell>
                  {vehicle.locationName || 'No location recorded'}
                </TableCell> */}
          
                {user?.role === 'admin' && (
                  <TableCell>
                    <IconButton
                      color="primary"
                      onClick={() => handleOpenDialog(vehicle)}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton
                      color="error"
                      onClick={() => handleDelete(vehicle.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
         <TablePagination
                          rowsPerPageOptions={[5, 10, 25]}
                          component="div"
                          count={totalCount}
                          rowsPerPage={rowsPerPage}
                          page={page}
                          onPageChange={handleChangePage}
                          onRowsPerPageChange={handleChangeRowsPerPage}
                        />
      </TableContainer>

      {/* Only render form when dialog is open */}
      {dialogOpen && (
        <VehicleForm
          open={dialogOpen}
          handleClose={handleCloseDialog}
          handleSubmit={handleSubmit}
          initialData={selectedVehicle}
          loading={loading}
        />
      )}
     

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default Vehicles;
