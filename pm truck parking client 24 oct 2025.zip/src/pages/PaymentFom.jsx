import React, { useEffect, useState } from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  Paper, Button, Dialog, DialogActions, DialogContent, DialogTitle,
  TextField, IconButton, MenuItem, Grid, Box
} from '@mui/material';
import api from '../services/api';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';

const PaymentFom = ({ open, handleClose, isEdit, formData, handleChange, handleSubmit, handleDataChange }) => {
  const [plates, setPlates] = useState([]);

  useEffect(() => {
    fetchPlates();
  }, []);


  const fetchPlates = async () => {
    try {
      const response = await api.get('/plates?page=0&limit=500');
      setPlates(response.data.plates || []);
    } catch (error) {
      console.error('Error fetching plates:', error);
      setPlates([]);
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm">
      <DialogTitle>{isEdit ? 'Update Payment' : 'Create Payment'}</DialogTitle>
      <DialogContent>
        <Box component="form" noValidate>
          <Grid container  spacing={2}>
            <Grid item xs={12} >
              <TextField
                name="plateId"
                label="Plate"
                fullWidth
                disabled={isEdit}
                value={formData.plateId || ''}
                onChange={handleChange}
                select
                InputLabelProps={{ shrink: true }}
              >
                {plates.map((plate) => (
                  <MenuItem key={plate.id} value={plate.id}>
                    {plate.number}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            {!isEdit && (
              <Grid item xs={12}>
                <TextField
                  name="totalamount"
                  label="Total Amount"
                  fullWidth
                  value={formData.totalamount || ''}
                  onChange={handleChange}
                />
              </Grid>
            )}

            <Grid item xs={12} sm={6}>
              <TextField
                name="amount"
                label="Amount"
                fullWidth
                value={formData.amount || ''}
                onChange={handleChange}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                name="paymentMethod"
                label="Payment Method"
                fullWidth
                select
                value={formData.paymentMethod || ''}
                onChange={handleChange}
              >
                {['Cash', 'Credit Card', 'Debit Card', 'Bank Transfer', 'Check', 'Mobile Payment'].map((method) => (
                  <MenuItem key={method} value={method}>
                    {method}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            <Grid item xs={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Payment Date"
                  value={formData.paymentDate ? new Date(formData.paymentDate) :null}
                  onChange={(date) => handleDataChange('paymentDate', date)}
                  renderInput={(params) => <TextField {...params} fullWidth />}
                />
              </LocalizationProvider>
            </Grid>

            {/* <Grid item xs={12} sm={6}>
              <TextField
                name="status"
                label="Status"
                fullWidth
                value={formData.status || ''}
                onChange={handleChange}
              />
            </Grid> */}

            <Grid item xs={12} sm={6}>
              <TextField
                name="party"
                label="Party"
                fullWidth
                value={formData.party || ''}
                onChange={handleChange}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                name="notes"
                label="Notes"
                fullWidth
                multiline
                minRows={2}
                value={formData.notes || ''}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained" color="primary">
          {isEdit ? 'Update' : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PaymentFom;
