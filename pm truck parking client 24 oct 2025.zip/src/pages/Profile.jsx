import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Tabs,
  Tab,
  Divider,
  Container
} from '@mui/material';
import UserVehicleUpload from '../components/UserVehicleUpload';
import { userAPI } from '../services/api';

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`profile-tabpanel-${index}`}
      aria-labelledby={`profile-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

const Profile = () => {
  const [tabValue, setTabValue] = useState(0);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const response = await userAPI.getCurrentUser();
        setUserProfile(response.data);
      } catch (error) {
        console.error('Error fetching user profile:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserProfile();
  }, []);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <Typography>Loading...</Typography>
      </Box>
    );
  }

  return (
    <Container maxWidth="lg">
      <Paper elevation={0} sx={{ mt: 3 }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            aria-label="profile tabs"
            centered
          >
            <Tab label="My Profile" />
            <Tab label="Add Vehicle" />
          </Tabs>
        </Box>

        <TabPanel value={tabValue} index={0}>
          <Box sx={{ p: 3 }}>
            <Typography variant="h5" gutterBottom>
              Profile Information
            </Typography>
            <Divider sx={{ mb: 3 }} />
            {userProfile && (
              <Box>
                <Typography variant="body1" gutterBottom>
                  <strong>Username:</strong> {userProfile.username}
                </Typography>
                <Typography variant="body1" gutterBottom>
                  <strong>Email:</strong> {userProfile.email}
                </Typography>
                <Typography variant="body1" gutterBottom>
                  <strong>Role:</strong> {userProfile.role}
                </Typography>
                <Typography variant="body1" gutterBottom>
                  <strong>Status:</strong> {userProfile.status}
                </Typography>
                <Typography variant="body1" gutterBottom>
                  <strong>Member Since:</strong>{' '}
                  {new Date(userProfile.createdAt).toLocaleDateString()}
                </Typography>
              </Box>
            )}
          </Box>
        </TabPanel>

        <TabPanel value={tabValue} index={1}>
          <UserVehicleUpload />
        </TabPanel>
      </Paper>
    </Container>
  );
};

export default Profile;
