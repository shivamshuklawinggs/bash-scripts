const getAddressFromCoordinates = async (latitude, longitude) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&addressdetails=1`
      );
      const data = await response.json();

      if (data && data.address) {
        const address = data.address;
        let location = '';

        if (address.suburb) location = address.suburb;
        else if (address.neighbourhood) location = address.neighbourhood;
        else if (address.residential) location = address.residential;
        else if (address.road)
          location = `${address.road}, ${address.city || address.town || address.village || ''}`;
        else if (address.city) location = address.city;
        else location = data.display_name.split(',')[0];

        return location;
      }
      return 'Location not available';
    } catch (error) {
      console.error('Error getting address:', error);
      return 'Location not available';
    }
  };
const getCurrentLocation = async () => {
    try {
      if (!navigator.geolocation) {
        return { latitude: 0, longitude: 0, location: 'Location not available' };
      }

      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        });
      });

      const { latitude, longitude } = position.coords;
      const location = await getAddressFromCoordinates(latitude, longitude);
      return { latitude, longitude, location };
    } catch (error) {
      console.error('Location error:', error);
      return { latitude: 0, longitude: 0, location: 'Location not available' };
    }
  };
  const getGoogleMapsLink = (latitude, longitude) => {
    if (!latitude || !longitude) return null;
    return `https://www.google.com/maps?q=${latitude},${longitude}`;
};
export { getCurrentLocation, getGoogleMapsLink };
  export default getCurrentLocation;