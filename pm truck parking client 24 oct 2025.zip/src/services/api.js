import axios from 'axios';

const API_URL = 'http://192.168.168.101:5002/api';
export const URL = 'http://192.168.168.101:5002/';
// const API_URL = 'https://api.pmtruckparking.com/api';
// export const URL = 'https://api.pmtruckparking.com/';
const TOKEN_KEY = 'parkingapp_token';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: API_URL,


  withCredentials: true,
  timeout: 10000
});


// Add auth token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Handle response errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

// Auth services
export const authAPI = {
  login: async (credentials) => {
    try {
      const response = await api.post('/auth/login', credentials);
      return response;
    } catch (error) {
      console.error('Login error:', error.response?.data || error.message);
      throw error;
    }
  },
  register: async (userData) => {
    try {
      const response = await api.post('/auth/register', userData);
      return response;
    } catch (error) {
      console.error('Registration error:', error.response?.data || error.message);
      throw error;
    }
  },
  logout: async () => {
    try {
      const response = await api.post('/auth/logout');
      localStorage.removeItem(TOKEN_KEY);
      return response;
    } catch (error) {
      console.error('Logout error:', error.response?.data || error.message);
      throw error;
    }
  },
  getCurrentUser: () => api.get('/auth/profile')
};

// User services
export const userAPI = {
  getAllUsers: async (filters = {}) => {
    try {
      const response = await api.get('/users', filters);
      console.log('getAllUsers response:', response.data);
      return response;
    } catch (error) {
      console.error('getAllUsers error:', error.response?.data || error.message);
      throw error;
    }
  },
  getRolesAndStatus: async () => {
    try {
      const response = await api.get('/users/rolesandstatus');
      return response;
    } catch (error) {
      console.error('getRolesAndStatus error:', error.response?.data || error.message);
      throw error;
    }
  },
  getUserById: async (id) => {
    try {
      const response = await api.get(`/users/${id}`);
      return response;
    } catch (error) {
      console.error('getUserById error:', error.response?.data || error.message);
      throw error;
    }
  },
  createUser: async (userData) => {
    try {
      const response = await api.post('/users', userData);
      return response;
    } catch (error) {
      console.error('createUser error:', error.response?.data || error.message);
      throw error;
    }
  },
  updateUser: async (id, userData) => {
    try {
      const response = await api.put(`/users/${id}`, userData);
      return response;
    } catch (error) {
      console.error('updateUser error:', error.response?.data || error.message);
      throw error;
    }
  },
  deleteUser: async (id) => {
    try {
      const response = await api.delete(`/users/${id}`);
      return response;
    } catch (error) {
      console.error('deleteUser error:', error.response?.data || error.message);
      throw error;
    }
  }
};

// Vehicle services
export const vehicleAPI = {
  // Get all plates
  getAllVehicles: (filters = {}) => {
    return api.get('/plates',filters);
  },

  // Get user's plates
  getUserVehicles: () => {
    return api.get('/plates/my-plates');
  },

  // Get plate by ID
  getVehicleById: (id) => {
    return api.get(`/plates/${id}`);
  },

  // Create new plate
  createVehicle: (plateData) => {
    return api.post('/plates', plateData);
  },

  // Update plate
  updateVehicle: (id, plateData) => {
    return api.put(`/plates/${id}`, plateData);
  },

  // Delete plate
  deleteVehicle: (id) => {
    return api.delete(`/plates/${id}`);
  },

  // Upload vehicle photo and check-in
  uploadVehiclePhoto: (formData) => {
    return api.post('/plates/check-in', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  }
};

// Parking Logs
export const getParkingLogs = async (params) => {
  const queryString = new URLSearchParams(params).toString();
  return await api.get(`/plates/checkin-logs?${queryString}`);
};

export const getPlateCheckInLogs = async (plateId, params) => {
  const queryString = new URLSearchParams(params).toString();
  return await api.get(`/plates/${plateId}/logs?${queryString}`);
};

// Dashboard services
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
  getActivity: () => api.get('/dashboard/activity')
};

export const paymentAPI = {
  getPayments: () => api.get('/payment'),
  createPayment: (paymentData) => api.post('/payment', paymentData),
  updatePayment: (id, paymentData) => api.put(`/payment/${id}`, paymentData),
  deletePayment: (id) => api.delete(`/payment/${id}`)
};

export default api;
