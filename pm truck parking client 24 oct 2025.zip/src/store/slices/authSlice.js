import { createSlice } from '@reduxjs/toolkit';

const TOKEN_KEY = 'parkingapp_token';
const USER_KEY = 'parkingapp_user';

// Load initial state from localStorage
const loadInitialState = () => {
  try {
    return {
      user: JSON.parse(localStorage.getItem(USER_KEY)),
      token: localStorage.getItem(TOKEN_KEY),
      isLoading: false,
      error: null
    };
  } catch (error) {
    console.error('Error loading auth state:', error);
    // Clear potentially corrupted data
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    return {
      user: null,
      token: null,
      isLoading: false,
      error: null
    };
  }
};

const authSlice = createSlice({
  name: 'auth',
  initialState: loadInitialState(),
  reducers: {
    loginStart: (state) => {
      state.isLoading = true;
      state.error = null;
    },
    loginSuccess: (state, action) => {
      const { user, token } = action.payload;
      state.isLoading = false;
      state.user = user;
      state.token = token;
      state.error = null;
      
      // Save to localStorage
      try {
        localStorage.setItem(TOKEN_KEY, token);
        localStorage.setItem(USER_KEY, JSON.stringify(user));
      } catch (error) {
        console.error('Error saving auth state:', error);
      }
    },
    loginFailure: (state, action) => {
      state.isLoading = false;
      state.error = action.payload;
      state.user = null;
      state.token = null;
      
      // Clear localStorage
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      state.error = null;
      
      // Clear localStorage
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    },
    clearError: (state) => {
      state.error = null;
    },
    updateUser: (state, action) => {
      state.user = { ...state.user, ...action.payload };
      try {
        localStorage.setItem(USER_KEY, JSON.stringify(state.user));
      } catch (error) {
        console.error('Error updating user state:', error);
      }
    }
  }
});

export const { 
  loginStart, 
  loginSuccess, 
  loginFailure, 
  logout, 
  clearError,
  updateUser 
} = authSlice.actions;

export default authSlice.reducer;
