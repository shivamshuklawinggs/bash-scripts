import * as React from 'react';
import {
  Dialog,
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Button,
  Box,
  Grid,
  Paper,
  Chip,
  Divider,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import Slide from '@mui/material/Slide';
import {
  Receipt as ReceiptIcon,
  Person as PersonIcon,
  DirectionsCar as CarIcon,
  CalendarToday as CalendarIcon,
  Notes as NotesIcon
} from '@mui/icons-material';
import { formatCurrency, formatDate, formateMonth, formateYear } from '../utils';

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const DetailItem = ({ icon, label, value }) => (
  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
    <Box sx={{ mr: 2, color: 'primary.main' }}>{icon}</Box>
    <Box>
      <Typography variant="caption" color="textSecondary">{label}</Typography>
      <Typography variant="body1">{value || 'N/A'}</Typography>
    </Box>
  </Box>
);

export default function PaymentDetails({ handleClose, payment }) {
  const handlePrint = () => {
    window.print();
  };
  if (!payment) return null;

  const getStatusChipColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'completed': return 'success';
      case 'pending': return 'warning';
      case 'failed': return 'error';
      case 'refunded': return 'info';
      default: return 'default';
    }
  };

  return (
    <Dialog fullScreen open={payment} onClose={handleClose} TransitionComponent={Transition}>
      <AppBar sx={{ position: 'relative' }} className='no-print'>
        <Toolbar>
          <IconButton edge="start" color="inherit" onClick={handleClose} aria-label="close">
            <CloseIcon />
          </IconButton>
          <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
            Payment Details
          </Typography>
          <Button color="inherit" onClick={handlePrint} >Print</Button>
        </Toolbar>
      </AppBar>

      <Box sx={{ p: 3 }} className="print-only">
        <Paper elevation={0} sx={{ p: 2, mb: 3, bgcolor: 'background.default' }}>
          <Grid container spacing={2}>
            <Grid item xs={6} sm={3}>
              <Typography variant="h6" gutterBottom>Payment #{payment?.id}</Typography>
              <Chip
                label={payment?.status || 'Unknown'}
                color={getStatusChipColor(payment?.status)}
                sx={{ mt: 1 }}
              />
            </Grid>
            <Grid item xs={6} sm={3}>
              <Typography variant="h4" color="primary">{formatCurrency(payment?.amount)}</Typography>
             
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="subtitle1" gutterBottom fontWeight="bold">Payment Summary</Typography>
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <Typography variant="body2" color="textSecondary">Total Amount:</Typography>
                  <Typography variant="body1" fontWeight="medium">{formatCurrency(payment?.totalAmount || 0)}</Typography>
                </Grid>
                <Grid item xs={4}>
                  <Typography variant="body2" color="textSecondary">Paid Amount:</Typography>
                  <Typography variant="body1" fontWeight="medium">{formatCurrency(payment?.paidAmount || 0)}</Typography>
                </Grid>
                <Grid item xs={4}>
                  <Typography variant="body2" color="textSecondary">Due Amount:</Typography>
                  <Typography variant="body1" fontWeight="medium" color={payment?.dueAmount > 0 ? 'error.main' : 'success.main'}>
                    {formatCurrency(payment?.dueAmount || 0)}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Paper>

        <Grid container spacing={3}>
          <Grid item xs={12} md={6} sx={{ 
            overflowY: 'auto',
            //  maxHeight: 'calc(100vh - 550px)',
             pb: 2 }}>
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">Payment Information</Typography>
            <TableContainer component={Paper} elevation={0}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Payment Date</TableCell>
                    <TableCell>Paid Amount</TableCell>
                    <TableCell>Payment Method</TableCell>
                    <TableCell>Month</TableCell>
                    <TableCell>Year</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {payment?.transactions?.slice().reverse().map((transaction) => (
                    <TableRow key={transaction?.id}>
                      <TableCell>{formatDate(transaction?.paymentDate)}</TableCell>
                      <TableCell>{formatCurrency(transaction?.amount)}</TableCell>
                      <TableCell>{transaction?.paymentMethod}</TableCell>
                      <TableCell>{formateMonth(transaction?.month)}</TableCell>
                      <TableCell>{formateYear(transaction?.year)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>

         
        </Grid>

        {payment?.notes && (
          <>
            <Divider sx={{ my: 3 }} />
            <Typography variant="subtitle1" gutterBottom fontWeight="bold">Notes</Typography>
            <Box sx={{ display: 'flex', alignItems: 'flex-start', mt: 1 }}>
              <NotesIcon sx={{ mr: 2, color: 'primary.main', mt: 0.5 }} />
              <Typography variant="body1">{payment?.notes}</Typography>
            </Box>
          </>
        )}
      </Box>
      <style>
      {`
          @media print {
            .no-print {
              display: none;
            }
            .print-only {
              display: block !important;
            }
            @page {
              size: landscape;
            }
            body {
              margin: 0;
              padding: 0;
            }
          }
        `}
      </style>
    </Dialog>
  );
}

