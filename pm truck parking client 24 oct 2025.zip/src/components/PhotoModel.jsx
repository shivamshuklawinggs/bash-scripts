import React from 'react'
import { Dialog, DialogTitle, DialogContent, IconButton, Typography } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { URL } from '../services/api'

const PhotoModel = ({selectedImage,handleCloseImage,}) => {
  return (
     <Dialog
     open={Boolean(selectedImage)}
     onClose={handleCloseImage}
     maxWidth="md"
     fullWidth
   >
     <DialogTitle sx={{ m: 0, p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
       <Typography>Photo</Typography>
       <IconButton
         aria-label="close"
         onClick={handleCloseImage}
         sx={{ color: 'grey.500' }}
       >
         <CloseIcon />
       </IconButton>
     </DialogTitle>
     <DialogContent>
       {selectedImage && (
         <img
           src={selectedImage}
           alt="Task completion"
           style={{
             width: '100%',
             height: 'auto',
             maxHeight: '70vh',
             objectFit: 'contain'
           }}
         />
       )}
     </DialogContent>
   </Dialog>
  )
}

export default PhotoModel