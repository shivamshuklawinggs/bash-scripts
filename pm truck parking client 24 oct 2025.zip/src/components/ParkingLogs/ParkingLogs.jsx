import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  TextField,
  MenuItem,
  Grid,
  Chip, IconButton,
  InputAdornment,
  Tooltip,
  FormControl, 
  InputLabel,  
  Select  
} from '@mui/material';
import { LocationOn,PhotoCamera as PhotoIcon,
  LocationOn as LocationIcon,
  Refresh as RefreshIcon,
  Close as CloseIcon, } from '@mui/icons-material'
import SearchIcon from '@mui/icons-material/Search';
import FlagIcon from '@mui/icons-material/Flag';
import dayjs from 'dayjs';
import api, { URL } from '../../services/api';
import PhotoPopup from '../comon/PhotoPopup';
import { getGoogleMapsLink } from '../../utils/getCurentLocation';

const ParkingLogs = () => {
  const [logs, setLogs] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [filters, setFilters] = useState({
    startDate: null,
    endDate: null,
    status: '',
    search: '',
    isUnregistered: 'all', 
  });

  const fetchLogs = async () => {
    try {
      const params = {
        page,
        limit: rowsPerPage,
        ...filters,
      };

      if (params.isUnregistered === 'all') {
        delete params.isUnregistered;
      }

      if (filters.startDate) {
        params.startDate = dayjs(filters.startDate).format('YYYY-MM-DD');
      }
      if (filters.endDate) {
        params.endDate = dayjs(filters.endDate).format('YYYY-MM-DD');
      }

      console.log('Fetching logs with params:', params);
      const response = await api.get('/plates/checkin-logs', { params });
      console.log('Response:', response.data);
      
      if (response.data && Array.isArray(response.data.logs)) {
        setLogs(response.data.logs);
        setTotalCount(response.data.count || 0);
      } else {
        console.error('Invalid response format:', response.data);
        setLogs([]);
        setTotalCount(0);
      }
    } catch (error) {
      console.error('Error fetching logs:', error);
      setLogs([]);
      setTotalCount(0);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [filters, page, rowsPerPage]);
 const [selectedImage, setSelectedImage] = useState(null);
  const handleImageClick = (photoUrl) => {
      setSelectedImage(`${URL}${photoUrl}`);
    };
  
    const handleCloseImage = () => {
      setSelectedImage(null);
    };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
    setPage(0);
  };

  return (
    <>
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Parking Logs
      </Typography>

      <Grid container spacing={2} sx={{ mb: 3, flexWrap: 'nowrap' }}>
        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="Search"
            value={filters.search}
            onChange={(e) => handleFilterChange('search', e.target.value)}
            placeholder="Search by plate number or vehicle type"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        </Grid>

        <Grid item xs={12} md={3} sx={{ position: 'relative' }}>
        <FormControl fullWidth variant="outlined">
          <InputLabel id="registration-status-label">
            Registration Status
            </InputLabel>
              <Select
                labelId="registration-status-label"
                value={filters.isUnregistered || ''}
                onChange={(e) => handleFilterChange('isUnregistered', e.target.value)}
                label="Registration Status"
                
              >
                <MenuItem value="all">All</MenuItem> 
                <MenuItem value= 'false'>Registered</MenuItem>
                <MenuItem value="true">Unregistered</MenuItem>
              </Select>
            </FormControl>
          </Grid>


        <Grid item xs={12} sm={3}>
          <TextField
            type="date"
            label="Start Date"
            value={filters.startDate || ''}
            onChange={(e) => handleFilterChange('startDate', e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={3}>
          <TextField
            type="date"
            label="End Date"
            value={filters.endDate || ''}
            onChange={(e) => handleFilterChange('endDate', e.target.value)}
            InputLabelProps={{ shrink: true }}
            fullWidth
          />
        </Grid>
      
      </Grid>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Plate Number</TableCell>
              <TableCell>Vehicle Type</TableCell>
              <TableCell>Check-In Time</TableCell>
              {/* <TableCell>Check-Out Time</TableCell> */}
              {/* <TableCell>Status</TableCell> */}
              <TableCell>Checked In By</TableCell>
              <TableCell>Location</TableCell>
              <TableCell>Photo</TableCell>
              {/* <TableCell>Checked Out By</TableCell> */}
            </TableRow>
          </TableHead>
          <TableBody>
            {logs.map((log) => (
              <TableRow key={log.id}>
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    {log.plate?.number || 'N/A'}
                    {log.plate?.isUnregistered && (
                      <Chip
                        icon={<FlagIcon />}
                        label="Unregistered"
                        size="small"
                        color="error"
                      />
                    )}
                  </Box>
                </TableCell>
                <TableCell>{log.plate?.vehicleType || 'N/A'}</TableCell>
                <TableCell>
                  {log.checkInTime ? dayjs(log.checkInTime).format('DD/MM/YYYY HH:mm') : 'N/A'}
                </TableCell>
                {/* <TableCell>
                  {log.checkOutTime ? dayjs(log.checkOutTime).format('DD/MM/YYYY HH:mm') : '-'}
                </TableCell> */}
                {/* <TableCell>{log.status || 'N/A'}</TableCell> */}
                <TableCell>{log.checkedInByUser?.username || 'N/A'}</TableCell>
                <TableCell>
                  {log.location ? (
                    <Tooltip title={log?.location}>
                      <IconButton size="small">
                        <a
                          href={getGoogleMapsLink(
                            log?.point?.coordinates?.[1],
                            log?.point?.coordinates?.[0]
                          )}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <LocationOn />  </a>
                      </IconButton>
                    </Tooltip>
                  ) : 'N/A'}
                </TableCell>
                 <TableCell>
                  {log.checkInPhotoUrl ? (
                    <IconButton
                      size="small"
                      onClick={() => handleImageClick(log.checkInPhotoUrl)}
                    >
                  <img src={`https://api.pmtruckparking.com/${log.checkInPhotoUrl}`} style={{width:"130px",height:"50px"}}/>                    </IconButton>
                  ) : '-'}
               </TableCell>
                {/* <TableCell>{log.checkedOutByUser?.username || '-'}</TableCell> */}
              </TableRow>
            ))}
            {logs.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  No records found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={totalCount}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
    </Box>
      <PhotoPopup selectedImage={selectedImage} handleCloseImage={handleCloseImage} />
    </>
  );
};

export default ParkingLogs;
