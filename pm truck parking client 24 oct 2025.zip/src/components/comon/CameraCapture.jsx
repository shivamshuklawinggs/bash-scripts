import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Button,
  Typography,
  CircularProgress,
} from '@mui/material';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import { Camera } from 'react-camera-pro';

const CameraCapture = ({ onPhotoCapture, onError }) => {
  const camera = useRef(null);
  const [showCamera, setShowCamera] = useState(false);
  const [isCameraAvailable, setIsCameraAvailable] = useState(true);
  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState('');

  const checkCameraAvailability = async () => {
    try {
      const devices = await navigator.mediaDevices?.enumerateDevices();
      const hasBackCamera = devices?.some(device => 
        device.kind === 'videoinput' && 
        (!device.label || device.label.toLowerCase().includes('back'))
      );
      setIsCameraAvailable(!!hasBackCamera);
      if (!hasBackCamera) {
        onError?.('Back camera is required. Please use a device with a back camera.');
      }
    } catch (err) {
      console.error('Error checking camera:', err);
      setIsCameraAvailable(false);
      onError?.('Camera access is required. Please allow camera access and refresh the page.');
    }
  };

  useEffect(() => {
    checkCameraAvailability();
  }, []);

  const handleTakePhoto = async () => {
    setLoading(true);
    try {
      const photo = camera.current?.takePhoto();
      if (!photo) {
        throw new Error('Failed to capture photo');
      }

      // Convert base64 to blob
      const response = await fetch(photo);
      const blob = await response.blob();
      const file = new File([blob], 'camera_photo.jpg', { type: 'image/jpeg' });
      
      setPreviewUrl(photo);
      setShowCamera(false);
      onPhotoCapture?.({ file, previewUrl: photo });
    } catch (err) {
      console.error('Camera error:', err);
      onError?.('Failed to take photo. Please try again.');
      setIsCameraAvailable(false);
    } finally {
      setLoading(false);
    }
  };

  const handleRemovePhoto = () => {
    setPreviewUrl('');
    onPhotoCapture?.(null);
  };

  if (!isCameraAvailable) {
    return (
      <Typography color="error" align="center">
        Camera access is required to take photos
      </Typography>
    );
  }

  return (
    <Box sx={{ width: '100%' }}>
      {showCamera ? (
        <Box sx={{ position: 'relative', height: '300px', mb: 2 }}>
          <Camera 
            ref={camera}
            facingMode="environment"
            errorMessages={{
              noCameraAccessible: 'Back camera not accessible. Please use a device with a back camera.',
              permissionDenied: 'Camera permission denied. Please allow camera access.',
              switchCamera: 'Back camera is not available.',
              canvas: 'Canvas is not supported in your browser.'
            }}
          />
          <Box sx={{ mt: 1, display: 'flex', gap: 1, justifyContent: 'center' }}>
            <Button 
              variant="contained" 
              onClick={handleTakePhoto}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Capture Photo'}
            </Button>
            <Button 
              variant="outlined" 
              onClick={() => setShowCamera(false)}
              disabled={loading}
            >
              Cancel
            </Button>
          </Box>
        </Box>
      ) : (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
          {previewUrl ? (
            <>
              <img
                src={previewUrl}
                alt="Captured"
                style={{ maxWidth: '100%', maxHeight: '200px' }}
              />
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Button 
                  variant="outlined"
                  onClick={() => setShowCamera(true)}
                >
                  Take New Photo
                </Button>
                <Button 
                  variant="text" 
                  color="error" 
                  onClick={handleRemovePhoto}
                >
                  Remove Photo
                </Button>
              </Box>
            </>
          ) : (
            <Button 
              variant="contained" 
              startIcon={<PhotoCameraIcon />}
              onClick={() => setShowCamera(true)}
            >
              Take Photo
            </Button>
          )}
        </Box>
      )}
    </Box>
  );
};

export default CameraCapture;
