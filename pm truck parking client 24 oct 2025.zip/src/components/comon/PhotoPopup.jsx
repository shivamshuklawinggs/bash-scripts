import React from 'react'
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Box, Typography, Alert, CircularProgress, IconButton } from '@mui/material'
import {
    PhotoCamera as PhotoIcon,
    LocationOn as LocationIcon,
    Refresh as RefreshIcon,
    Close as CloseIcon,
  } from '@mui/icons-material';
  
const PhotoPopup = ({selectedImage,handleCloseImage}) => {
    return  <Dialog
    open={Boolean(selectedImage)}
    onClose={handleCloseImage}
    maxWidth="md"
    fullWidth
  >
    <DialogTitle sx={{ m: 0, p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <Typography>Task Photo</Typography>
      <IconButton
        aria-label="close"
        onClick={handleCloseImage}
        sx={{ color: 'grey.500' }}
      >
        <CloseIcon />
      </IconButton>
    </DialogTitle>
    <DialogContent>
      {selectedImage && (
        <img
          src={selectedImage}
          alt="Task completion"
          style={{
            width: '100%',
            height: 'auto',
            maxHeight: '70vh',
            objectFit: 'contain'
          }}
        />
      )}
    </DialogContent>
  </Dialog>
}

export default PhotoPopup