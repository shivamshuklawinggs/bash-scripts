import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Switch,
  Alert,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import getCurrentLocation from '../../utils/getCurentLocation';

const VehicleCheckIn = () => {
  const navigate = useNavigate();
  const [selectedPlate, setSelectedPlate] = useState('');
  const [plates, setPlates] = useState([]);
  const [photo, setPhoto] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isUnregistered, setIsUnregistered] = useState(false);
  const [unregisteredDetails, setUnregisteredDetails] = useState({
    number: '',
    vehicleType: 'truck',
    Name: '',
    Phone: '',
    CompanyName: '',
    MakeModel: '',
    Color: '',
    location: '',
    latitude: '',
    longitude: '',
    photo: '',
  });

  useEffect(() => {
    fetchPlates();
  }, []);

  const fetchPlates = async () => {
    try {
      const response = await api.get('/plates?isUnregistered=false');
      setPlates(response.data.plates || []);
    } catch (error) {
      console.error('Error fetching plates:', error);
      setError('Failed to fetch plates');
    }
  };

  const handlePhotoChange = (event) => {
    setPhoto(event.target.files[0]);
  };

  const handleUnregisteredDetailsChange = (field) => (event) => {
    setUnregisteredDetails(prev => ({
      ...prev,
      [field]: event.target.value
    }));
  };

  const validateUnregisteredDetails = () => {
    const required = ['number', 'vehicleType', ];
    for (const field of required) {
      if (!unregisteredDetails[field]) {
        setError(`${field.charAt(0).toUpperCase() + field.slice(1)} is required`);
        return false;
      }
    }
    return true;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);
  
    try {
      const { location, latitude, longitude } = await getCurrentLocation();
      if (!location || !latitude || !longitude) return handleError('Failed to get current location');
      if (isUnregistered && !validateUnregisteredDetails()) return setLoading(false);
  
      if (!photo) return handleError('Please select a photo');
  
  
      const formData = new FormData();
      formData.append('photo', photo);
      formData.append('location', location);
      formData.append('point', JSON.stringify({ type: 'Point', coordinates: [longitude, latitude] }));

  
      if (isUnregistered) {
        setUnregisteredDetails(prev => ({
          ...prev,
          latitude,
          longitude,
          location,
        }));
        await createTemporaryPlate(location,longitude,latitude);
      } else {
        if (!selectedPlate) return handleError('Please select a plate');
        formData.append('plateId', selectedPlate);
        await api.post('/plates/check-in', formData);
        handleSuccess();
      }
    } catch (error) {
      handleError(error.response?.data?.message || 'Failed to check in vehicle');
    } finally {
      setLoading(false);
    }
  };
  
  // **Helper functions for better readability**
  const handleError = (message) => {
    setError(message);
    setLoading(false);
  };
  
  const handleSuccess = () => {
    setSuccess('Vehicle checked in successfully');
    setTimeout(() => navigate('/dashboard'), 2000);
  };
  
  const createTemporaryPlate = async (location="N/A", longitude=0, latitude=0) => {
    const data = new FormData();
    data.append('number', unregisteredDetails.number);
    data.append('vehicleType', unregisteredDetails.vehicleType);
    data.append('photo', photo);
    data.append('location', location);
    data.append('point', JSON.stringify({ type: 'Point', coordinates: [longitude, latitude] }));
    
    await api.post('/plates/temporary', data);
    handleSuccess();
  };
  

  return (
    <Box sx={{ p: 3 }}>
      <Paper elevation={3} sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
        <Typography variant="h5" gutterBottom>
          Vehicle Check-In
        </Typography>

        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Switch
                    checked={isUnregistered}
                    onChange={(e) => setIsUnregistered(e.target.checked)}
                  />
                }
                label="Unregistered Vehicle"
              />
            </Grid>

            {isUnregistered ? (
              // Unregistered vehicle form
              <>
                <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    label="Plate Number"
                    value={unregisteredDetails.number}
                    onChange={handleUnregisteredDetailsChange('number')}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth required>
                    <InputLabel>Vehicle Type</InputLabel>
                    <Select
                      value={unregisteredDetails.vehicleType}
                      onChange={handleUnregisteredDetailsChange('vehicleType')}
                      label="Vehicle Type"
                    >
                      <MenuItem value="car">Car</MenuItem>
                      <MenuItem value="truck">Truck</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
               {/* <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    label="Driver/Owner Name"
                    value={unregisteredDetails.Name}
                    onChange={handleUnregisteredDetailsChange('Name')}
                  />
                </Grid>
                 <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    label="Phone Number"
                    value={unregisteredDetails.Phone}
                    onChange={handleUnregisteredDetailsChange('Phone')}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Company Name"
                    value={unregisteredDetails.CompanyName}
                    onChange={handleUnregisteredDetailsChange('CompanyName')}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Make/Model"
                    value={unregisteredDetails.MakeModel}
                    onChange={handleUnregisteredDetailsChange('MakeModel')}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Color"
                    value={unregisteredDetails.Color}
                    onChange={handleUnregisteredDetailsChange('Color')}
                  />
                </Grid> */}
              </>
            ) : (
              // Registered vehicle selection
              <Grid item xs={12}>
                <FormControl fullWidth required>
                  <InputLabel>Select Vehicle</InputLabel>
                 
                  <Select
                    value={selectedPlate}
                    onChange={(e) => setSelectedPlate(e.target.value)}
                    label="Select Vehicle"
                  >
                     {/* BE DEFAULT ADD FIRST AS A UNREGISTRED VEHICLE */}
                    <MenuItem value={isUnregistered} onClick={()=>setIsUnregistered(!isUnregistered)}>Unregistered Vehicle</MenuItem>
                    {plates.map((plate) => (
                      <MenuItem key={plate.id} value={plate.id}>
                        {plate.number} - {plate.vehicleType}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            )}

            <Grid item xs={12}>
              <input
                accept="image/*"
                style={{ display: 'none' }}
                id="photo-upload"
                type="file"
                onChange={handlePhotoChange}
              />
              <label htmlFor="photo-upload">
                <Button variant="contained" component="span">
                  Upload Photo
                </Button>
              </label>
              {photo && (
                <Typography variant="body2" sx={{ mt: 1 }}>
                  Selected: {photo.name}
                </Typography>
              )}
            </Grid>

            {error && (
              <Grid item xs={12}>
                <Alert severity="error">{error}</Alert>
              </Grid>
            )}

            {success && (
              <Grid item xs={12}>
                <Alert severity="success">{success}</Alert>
              </Grid>
            )}

            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                disabled={loading}
                fullWidth
              >
                {loading ? 'Checking In...' : 'Check In'}
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Box>
  );
};

export default VehicleCheckIn;
