import React, { useState, useRef } from 'react';
import {
  Box,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  CircularProgress,
  Alert,
  Snackbar,
  Paper,
  Grid,
  Card,
  CardMedia
} from '@mui/material';
import { PhotoCamera } from '@mui/icons-material';
import { vehicleAPI } from '../../services/api';
import CameraCapture from '../comon/CameraCapture';

const PlateUpload = ({ plates = [], onSuccess }) => {
  const [plateId, setPlateId] = useState('');
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  const fileInputRef = useRef();
  const handlePhotoCapture = (photoData) => {
    if (photoData) {
      setPhoto(photoData.file);
      setError('');
    } else {
      setPhoto(null);
    }
  };
  const handlePlateChange = (e) => {
    setPlateId(e.target.value);
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPhoto(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!plateId) {
      setError('Please select a license plate');
      return;
    }

    if (!photo) {
      setError('Please take a photo of the vehicle');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('plateId', plateId);
      formData.append('photo', photo);
      formData.append('type', 'checkout');

      await vehicleAPI.uploadVehiclePhoto(formData);
      
      const selectedPlate = plates.find(p => p.id === plateId);
      setSnackbar({
        open: true,
        message: `Vehicle ${selectedPlate?.number || ''} checked in successfully`,
        severity: 'success'
      });

      // Reset form
      setPlateId('');
      setPhoto(null);
      setPhotoPreview(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error('Error checking in vehicle:', error);
      setError(error.response?.data?.message || 'Failed to check in vehicle');
      setSnackbar({
        open: true,
        message: 'Failed to check in vehicle',
        severity: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  return (
    <Box sx={{ p: 3, maxWidth: 800, mx: 'auto' }}>
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography variant="h5" gutterBottom>
          Vehicle Check-out
        </Typography>
        
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Select License Plate</InputLabel>
                <Select
                  value={plateId}
                  onChange={handlePlateChange}
                  label="Select License Plate"
                  required
                >
                  {plates.map((plate) => (
                    <MenuItem key={plate.id} value={plate.id}>
                      {plate.number} - {plate.vehicleType}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <Button
                variant="contained"
                startIcon={<PhotoCamera />}
                onClick={() => fileInputRef.current?.click()}
                fullWidth
              >
                Take Photo
              </Button>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoChange}
                ref={fileInputRef}
                style={{ display: 'none' }}
              />
            </Grid>

            {photoPreview && (
              <Grid item xs={12}>
                <Card>
                  <CardMedia
                    component="img"
                    image={photoPreview}
                    alt="Vehicle photo preview"
                    sx={{ height: 200, objectFit: 'cover' }}
                  />
                </Card>
              </Grid>
            )}

            {error && (
              <Grid item xs={12}>
                <Alert severity="error">{error}</Alert>
              </Grid>
            )}

            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
                disabled={loading || !plateId || !photo}
              >
                {loading ? <CircularProgress size={24} /> : 'Check In Vehicle'}
              </Button>
            </Grid>
          </Grid>
        </form>

        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={handleCloseSnackbar}
        >
          <Alert
            onClose={handleCloseSnackbar}
            severity={snackbar.severity}
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Paper>
    </Box>
  );
};

export default PlateUpload;
