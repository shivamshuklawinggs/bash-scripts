import React, { useState, useEffect } from 'react';
import {
  Box,
  CircularProgress,
  Alert,
  Paper,
  Typography
} from '@mui/material';
import { vehicleAPI } from '../../services/api';
import PlateUpload from './PlateUpload';

const VehicleCheckOut = () => {
 
  const [plates, setPlates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
 
  useEffect(() => {
    const fetchPlates = async () => {
      try {
        const response = await vehicleAPI.getAllVehicles();
        console.log('API Response:', response);
        setPlates(response.data.plates || []);
        setError(null);
      } catch (error) {
        console.error('Error fetching plates:', error);
        setError('Failed to load plates. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchPlates();
  }, []);

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          minHeight: '60vh'
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  if (!plates.length) {
    return (
      <Paper elevation={3} sx={{ p: 3, maxWidth: 600, mx: 'auto', mt: 4 }}>
        <Typography variant="h6" align="center" gutterBottom>
          No Plates Available
        </Typography>
        <Alert severity="info">
          No plates have been registered in the system yet.
        </Alert>
      </Paper>
    );
  }

  return (
    <PlateUpload
      plates={plates}
      onSuccess={() => {
        // You can add any additional success handling here
      }}
    />
  );
};

export default VehicleCheckOut;
