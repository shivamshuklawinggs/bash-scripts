import React, { useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  MenuItem,
  FormControl,
  FormHelperText,
} from '@mui/material';

// Validation schema
const validationSchema = yup.object().shape({
  number: yup.string()
    .required('License plate number is required')
    .min(3, 'License plate number must be at least 3 characters')
    .matches(/^[A-Za-z0-9\s-]+$/, 'Invalid license plate format'),
  vehicleType: yup.string()
    .required('Vehicle type is required')
    .oneOf(['truck', 'car'], 'Invalid vehicle type'),
  CompanyName: yup.string()
    .required('Company name is required')
    .min(2, 'Company name must be at least 2 characters'),
  Name: yup.string()
    .required('Company owner name is required')
    .min(2, 'Name must be at least 2 characters'),
  Phone: yup.string()
    .required('Phone number is required')
    .matches(/^[0-9]{10}$/, 'Phone number must be 10 digits'),
  Email: yup.string()
    .email('Invalid email format')
    .required('Email is required'),
  MakeModel: yup.string()
    .required('Make/Model is required'),
  Color: yup.string()
    .required('Color is required'),
  Rent: yup.number()
    .typeError('Rent must be a number')
    .required('Rent is required')
    .min(0, 'Rent cannot be negative'),
  Remote: yup.boolean(),
  RemoteNumber: yup.string()
  .when('Remote', {
    is: true,
    then: (schema) => schema.required('Remote number is required when Remote is enabled'),
    otherwise: (schema) => schema
  }),
  DriverName: yup.string(),
  DriverPhone: yup.string().matches(/^[0-9]{10}$/, 'Driver Phone number must be 10 digits'),
});

const VehicleForm = ({ open, handleClose, handleSubmit: onSubmit, initialData, loading }) => {
  const defaultValues = {
    number: '',
    vehicleType: 'truck',
    CompanyName: '',
    Name: '',
    Phone: '',
    Email: '',
    MakeModel: '',
    Color: '',
    Rent: '',
    Remote: false,
    RemoteNumber: '',
    DriverName: '',
    DriverPhone: '',
  };

  const { control, handleSubmit, reset, watch, formState: { errors } } = useForm({
    resolver: yupResolver(validationSchema),
    mode: "onChange",
    defaultValues
  });

  const isRemote = watch('Remote');

  useEffect(() => {
    if (initialData) {
      reset({
        number: initialData.number || '',
        vehicleType: initialData.vehicleType || 'truck',
        CompanyName: initialData.CompanyName || '',
        Name: initialData.Name || '',
        Phone: initialData.Phone || '',
        Email: initialData.Email || '',
        MakeModel: initialData.MakeModel || '',
        Color: initialData.Color || '',
        Rent: initialData.Rent || '',
        Remote: initialData.Remote || false,
        RemoteNumber: initialData.RemoteNumber || '',
        DriverName: initialData.DriverName || '',
        DriverPhone: initialData.DriverPhone || '',
      });
    } else {
      reset(defaultValues);
    }
  }, [initialData, reset]);

  const onFormSubmit = (data) => {
    onSubmit(data);
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        {initialData ? 'Edit Vehicle' : 'Add New Vehicle'}
      </DialogTitle>
      <DialogContent>
        <form onSubmit={handleSubmit(onFormSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1rem' }}>
          <Controller
            name="number"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="License Plate Number"
                error={!!errors.number}
                helperText={errors.number?.message}
                required
              />
            )}
          />

          <Controller
            name="vehicleType"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                select
                fullWidth
                label="Vehicle Type"
                error={!!errors.vehicleType}
                helperText={errors.vehicleType?.message}
                required
              >
                <MenuItem value="truck">Truck</MenuItem>
                <MenuItem value="car">Car</MenuItem>
              </TextField>
            )}
          />

          <Controller
            name="CompanyName"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Company Name"
                error={!!errors.CompanyName}
                helperText={errors.CompanyName?.message}
                required
              />
            )}
          />

          <Controller
            name="Name"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Company Owner Name"
                error={!!errors.Name}
                helperText={errors.Name?.message}
                required
              />
            )}
          />

          <Controller
            name="Phone"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Phone"
                type="number"
                error={!!errors.Phone}
                helperText={errors.Phone?.message}
                required
              />
            )}
          />

          <Controller
            name="Email"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Email"
                type="email"
                error={!!errors.Email}
                helperText={errors.Email?.message}
                required
              />
            )}
          />

          <Controller
            name="MakeModel"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Make/Model"
                error={!!errors.MakeModel}
                helperText={errors.MakeModel?.message}
                required
              />
            )}
          />

          <Controller
            name="Color"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Color"
                error={!!errors.Color}
                helperText={errors.Color?.message}
                required
              />
            )}
          />

          <Controller
            name="Rent"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Rent"
                type="number"
                error={!!errors.Rent}
                helperText={errors.Rent?.message}
                required
              />
            )}
          />

          <FormControl error={!!errors.Remote}>
            <Controller
              name="Remote"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  select
                  fullWidth
                  label="Remote"
                  value={field.value ? true : false}
                >
                  <MenuItem value={true}>Yes</MenuItem>
                  <MenuItem value={false}>No</MenuItem>
                </TextField>
              )}
            />
            {errors.Remote && <FormHelperText>{errors.Remote.message}</FormHelperText>}
          </FormControl>

          {isRemote && (
            <Controller
              name="RemoteNumber"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  fullWidth
                  label="Remote Number"
                  error={!!errors.RemoteNumber}
                  helperText={errors.RemoteNumber?.message}
                  required
                />
              )}
            />
          )}

          <Controller
            name="DriverName"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                label="Driver Name"
                error={!!errors.DriverName}
                helperText={errors.DriverName?.message}
              />
            )}
          />

          <Controller
            name="DriverPhone"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                fullWidth
                type="number"
                label="Driver Phone"
                error={!!errors.DriverPhone}
                helperText={errors.DriverPhone?.message}
              />
            )}
          />
        </form>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button 
          onClick={handleSubmit(onFormSubmit)}
          variant="contained" 
          color="primary"
          disabled={loading}
        >
          {loading ? 'Saving...' : (initialData ? 'Update' : 'Add')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default VehicleForm;
