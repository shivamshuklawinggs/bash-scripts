import { Navigate, Outlet } from 'react-router-dom';
import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Box, CircularProgress } from '@mui/material';
import { authAPI } from '../services/api';
import { loginSuccess, logout } from '../store/slices/authSlice';

const PrivateRoute = () => {
  const dispatch = useDispatch();
  const { user, token } = useSelector((state) => state.auth);

  useEffect(() => {
    const verifyToken = async () => {
      if (token && !user) {
        try {
          const response = await authAPI.getProfile();
          dispatch(loginSuccess({ user: response.data, token }));
        } catch (error) {
          console.error('Token verification failed:', error);
          dispatch(logout());
        }
      }
    };

    verifyToken();
  }, [token, user, dispatch]);

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  if (!user) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return <Outlet />;
};

export default PrivateRoute;
